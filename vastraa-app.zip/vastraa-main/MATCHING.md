# Product Entity-Resolution and Matching Platform

This module adds cross-marketplace product matching to Vastra. It decides when listings from different sellers describe the same product, even with inconsistent titles, missing identifiers, different languages and different photographs. It then produces unified product IDs, a deduplicated catalog and confidence-scored match links. Uncertain pairs are routed to a human reviewer.

The module is additive. No existing Vastra route, screen or behaviour was changed. The only edits to existing files are one line in `backend/server.js` that mounts the API, one route in `frontend/src/App.jsx`, new npm scripts, and the `jimp` dependency.

## Running it

All commands run from the `backend` folder.

| Command | Purpose | Needs MongoDB |
|---|---|---|
| `npm run match` | Runs the pipeline and prints metrics, the threshold sweep and the review queue | No |
| `npm run match:errors` | Same, plus the lists of false merges and missed matches | No |
| `npm run match:test` | Runs the 29 unit and integration tests | No |
| `npm run match:bench -- --sizes 1000,10000,50000` | Scalability benchmark on synthetic catalogs | No |
| `npm run match:generate -- --seed 2026` | Regenerates the labelled dataset and images | No |
| `npm run dev` | Starts the API, including `/api/matching` | Yes |

Once the backend and frontend are running, the review interface is at `http://localhost:3000/match-review`. Recording review decisions requires a signed-in user; viewing does not.

## Pipeline

```
Listings from 4 sellers
  -> Ingestion and validation
  -> Normalisation (Unicode, Hindi translation, synonyms, attributes)
  -> Feature extraction (TF-IDF embeddings, perceptual image hashes)
  -> Blocking (5 independent passes, union of candidate pairs)
  -> Scoring (identifier rules, weighted fuzzy score, penalties)
  -> Decision: auto-match / human review / non-match
  -> Clustering (guarded Union-Find, two levels)
  -> Unified product IDs, deduplicated catalog, match links
  -> Evaluation against ground truth
```

## Where each topic of the abstract is implemented

| Topic | File | Data structures and algorithms |
|---|---|---|
| Data ingestion | `matching/core/pipeline.js` (`ingest`) | Hash set for duplicate detection; malformed listings are rejected with a reason rather than failing the run |
| Normalisation | `matching/text/normalize.js` | NFKC Unicode normalisation, diacritic stripping, hyphen joining, synonym hash map, stopword set |
| Multilingual listings | `matching/text/normalize.js`, `matching/text/transliterate.js`, `matching/ds/trie.js` | Trie with longest-prefix matching for Hindi-to-English translation; rule-based Devanagari transliteration with schwa deletion as a fallback |
| Rule-based matching (GTIN, UPC, EAN) | `matching/rules/gtin.js` | GS1 mod-10 check-digit validation; canonical 14-digit form so UPC-A and EAN-13 codes compare equal |
| Brand-model patterns | `matching/text/attributes.js` | Regular expression for style codes such as `VO-KUR-1001` |
| Blocking and candidate generation | `matching/blocking/index.js` | Hash-based standard blocking, sorted neighbourhood (sort plus sliding window), MinHash with LSH banding, BK-tree image search, random-hyperplane LSH on embeddings |
| Fuzzy string matching | `matching/similarity/string.js` | Levenshtein and Damerau-Levenshtein by dynamic programming with early exit, Jaccard and typo-tolerant soft Jaccard, Jaro-Winkler |
| Semantic embeddings | `matching/similarity/embedding.js` | TF-IDF weighted word and character-trigram features, feature hashing, cosine similarity, k-nearest neighbours with a bounded min-heap |
| Image-based visual similarity | `matching/similarity/imageHash.js`, `matching/ds/bkTree.js` | Perceptual hash from a separable 2-D DCT, Hamming distance by SWAR popcount, BK-tree range queries |
| Scoring engine | `matching/core/scoring.js`, `matching/config.js` | Weighted combination with weight redistribution for missing features; brand, category and style-code penalties; threshold bands |
| Clustering into unified IDs | `matching/core/clustering.js`, `matching/ds/unionFind.js` | Union-Find with path compression and union by rank; edges applied in descending score order, as in Kruskal's algorithm; a metadata guard vetoes merges that would combine conflicting identifiers |
| Variant differentiation | `matching/text/attributes.js`, `matching/core/clustering.js` | Colour, size and pack extraction; a second Union-Find level builds the Family, Variant and Listing hierarchy |
| Human-in-the-loop review | `matching/core/pipeline.js`, `matching/core/reviewStore.js`, `frontend/src/screens/MatchReview.jsx` | Min-heap ordered by uncertainty; hash map of stored decisions that override the model; atomic file writes |
| Precision versus recall | `matching/core/evaluation.js` | Hash sets of pair keys; precision, recall and F1 at item and product level; threshold sweep; blocking completeness and reduction ratio |

## Complexity

| Operation | Time | Notes |
|---|---|---|
| All-pairs comparison (the baseline avoided) | O(n²) | 1.25 billion pairs at 50,000 listings |
| Standard blocking | O(n + Σ bᵢ²) | Blocks above 100 listings fall back to a sorted window, keeping each block linear |
| Sorted neighbourhood | O(n log n + n·w) | Window w = 5 |
| MinHash signatures | O(n · s · h) | s shingles per title, h = 50 hash functions |
| BK-tree image query | Sub-linear in practice | Subtrees outside [d − r, d + r] are pruned by the triangle inequality |
| Levenshtein | O(m · n) time, O(min(m, n)) memory | Two-row dynamic programming with early exit |
| Union-Find, per operation | O(α(n)) amortised | α is the inverse Ackermann function, below 5 for any practical n |
| Review queue | O(n) build, O(k log n) for the top k | Bottom-up heapify |
| k nearest neighbours | O(n log k) per query | Bounded min-heap |

## Results

**Labelled dataset.** The generator in `matching/scripts/generate-datasets.js` builds 113 listings from Vastra's own catalog and photographs. Vastra contributes 30 listings. TrendKart has 33, with typos, reordered titles, brand spelling variants, corrupted GTINs and pack variants. BazaarHub has 42, with Hindi titles, different category labels, missing brands, colour variants and same-seller duplicates. StyleMart has 8 look-alike products from other brands, which must stay unmatched.

| Measure | Seed 2026 (default) | Seeds 7, 99 and 31337 |
|---|---|---|
| Precision, same item | 100% | 99.0% to 100% |
| Recall, same item | 100% | 93.1% to 98.0% |
| Blocking pair completeness | 100% | 100% |
| Comparisons avoided | 84.7% | about 80% |
| Look-alike products merged by mistake | 0 of 8 | 0 of 8 |
| Pairs sent to human review | 9 | 10 to 15 |

The range across seeds is the more reliable figure. The perfect result on the default seed reflects one particular dataset.

**Scalability.** Synthetic catalogs without images, measured in a 4 GB sandbox:

| Listings | Possible pairs | Pairs compared | Avoided | True pairs kept | Precision | Recall | Total time |
|---|---|---|---|---|---|---|---|
| 1,000 | 499,500 | 11,593 | 97.68% | 100% | 100% | 95.2% | 0.5 s |
| 10,000 | 49,995,000 | 192,046 | 99.62% | 100% | 99.9% | 94.1% | 3.2 s |
| 50,000 | 1,249,975,000 | 2,301,667 | 99.82% | 100% | 98.6% | 93.8% | 31 s |

## Design decisions

The auto-match threshold is 0.80 and the review band is 0.60 to 0.80. The threshold sweep shows that precision stays near 99% down to 0.50, while recall falls steeply above 0.80. Pairs between 0.60 and 0.80 therefore go to a reviewer rather than being merged or discarded automatically. That keeps false merges near zero, which matters more than missed matches in a catalog.

Identifiers are trusted but verified. A GTIN is used only if its check digit is valid, since a corrupted code would otherwise cause a confident wrong merge. Identical GTINs with conflicting colours are sent to review rather than merged.

The cluster guard exists because pairwise matching is not transitive. A listing with no stated colour can match both the red and the brown variant of a product. Without the guard, Union-Find would chain the two variants together. With it, the second merge is refused and reported.

## Limitations and future scope

The embeddings are built from scratch as TF-IDF vectors over words and character trigrams. They capture spelling and word overlap, not deep meaning. The pipeline depends only on the `embed(tokens)` interface, so a pretrained multilingual sentence encoder can be substituted without other changes.

The Hindi support uses a curated apparel dictionary with a phonetic fallback. Other scripts would need their own dictionaries.

Scale has been measured up to 50,000 listings in memory. Catalogs with millions of SKUs would need the same algorithms run over persistent storage, such as MongoDB collections for candidate pairs, and would need sharding by blocking key.

The evaluation dataset is generated from Vastra's catalog. It is labelled and reproducible, but it is not a sample of real third-party marketplace data.

## API reference

Base path: `/api/matching`. Endpoints marked "Auth" require a JWT bearer token.

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/summary` | No | Counts, decisions, cluster statistics, timings and headline metrics |
| GET | `/evaluation` | No | Full evaluation including threshold sweep and error lists |
| GET | `/review?limit=10` | No | Next review items, least certain first |
| POST | `/review` | Auth | Body `{ "key": "A::B", "decision": "accept" }` or `"reject"` |
| POST | `/review/undo` | Auth | Body `{ "key": "A::B" }` |
| GET | `/catalog?offset=0&limit=50` | No | Deduplicated catalog: families with variants and listings |
| GET | `/links?decision=match&relation=variant` | No | Scored match links |
| GET | `/listings/:id` | No | One listing with its unified and family IDs |
| GET | `/listings/:id/similar?k=5` | No | Nearest listings by embedding |
| POST | `/run` | Auth | Recomputes from the dataset files |
| GET | `/images/*` | No | Listing photographs |
