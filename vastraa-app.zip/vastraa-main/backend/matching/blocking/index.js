'use strict';

const { BKTree } = require('../ds/bkTree');
const { fnv1a32, mix32 } = require('../core/hash');
const { hammingDistance } = require('../similarity/imageHash');

/**
 * Candidate generation.
 *
 * Comparing every pair of n listings costs n(n - 1) / 2 comparisons, which
 * is about 5 x 10^11 for a million listings. Blocking proposes a small set
 * of plausible pairs instead. No single blocking key is reliable (a typo in
 * a brand breaks brand blocking, a reordered title breaks sorted
 * neighbourhood), so several independent passes run and their outputs are
 * unioned: a true match only needs to be proposed by one of them.
 */

/** Canonical, order-independent key for an unordered pair of ids. */
function pairKey(a, b) {
  return a < b ? `${a}::${b}` : `${b}::${a}`;
}

function splitPairKey(key) {
  const [a, b] = key.split('::');
  return { a, b };
}

/**
 * Hash-map-backed set of candidate pairs, recording which blocking passes
 * proposed each pair (useful for evaluating each pass separately).
 */
class CandidateSet {
  constructor() {
    this._pairs = new Map();
  }

  get size() {
    return this._pairs.size;
  }

  add(a, b, source) {
    if (a === b) return;
    const key = pairKey(a, b);
    let sources = this._pairs.get(key);
    if (!sources) {
      sources = new Set();
      this._pairs.set(key, sources);
    }
    sources.add(source);
  }

  has(a, b) {
    return this._pairs.has(pairKey(a, b));
  }

  sourcesOf(key) {
    return this._pairs.get(key) || new Set();
  }

  keys() {
    return this._pairs.keys();
  }

  entries() {
    return this._pairs.entries();
  }

  countBySource() {
    const counts = {};
    for (const sources of this._pairs.values()) {
      for (const source of sources) counts[source] = (counts[source] || 0) + 1;
    }
    return counts;
  }
}

function addAllPairsInBucket(ids, candidates, source) {
  for (let i = 0; i < ids.length; i += 1) {
    for (let j = i + 1; j < ids.length; j += 1) candidates.add(ids[i], ids[j], source);
  }
}

/**
 * Standard (key-based) blocking: listings sharing a blocking key land in the
 * same hash bucket and only pairs inside a bucket are compared.
 *
 * A bucket larger than `maxBlockSize` (a big brand, say) would reintroduce
 * quadratic cost, so it is not compared all-pairs. Instead its members are
 * sorted by title and only neighbours within `window` positions are paired,
 * keeping the cost of that bucket linear in its size.
 */
function standardBlocking(records, keyFn, candidates, {
  maxBlockSize = 100,
  window = 10,
  source = 'standard',
  sortKey = (record) => record.coreSorted,
} = {}) {
  const buckets = new Map();
  for (const record of records) {
    const key = keyFn(record);
    if (!key) continue;
    let bucket = buckets.get(key);
    if (!bucket) {
      bucket = [];
      buckets.set(key, bucket);
    }
    bucket.push(record);
  }
  const oversized = [];
  for (const [key, members] of buckets) {
    if (members.length <= maxBlockSize) {
      addAllPairsInBucket(members.map((r) => r.listingId), candidates, source);
      continue;
    }
    oversized.push({ key, size: members.length });
    sortedNeighbourhood(members, sortKey, candidates, { window, source });
  }
  return { buckets: buckets.size, oversized: oversized.length, largestOversized: oversized.reduce((m, o) => Math.max(m, o.size), 0) };
}

/**
 * Sorted neighbourhood method: sort records by a key, then slide a window
 * of size `window` over the sorted order and pair records inside it.
 * O(n log n + n * window). Catches near-identical keys that differ by a
 * typo and therefore hash to different standard blocks.
 */
function sortedNeighbourhood(records, keyFn, candidates, { window = 5, source = 'sorted-neighbourhood' } = {}) {
  const keyed = records
    .map((record) => ({ id: record.listingId, key: keyFn(record) }))
    .filter((entry) => entry.key)
    .sort((x, y) => (x.key < y.key ? -1 : x.key > y.key ? 1 : 0));
  for (let i = 0; i < keyed.length; i += 1) {
    for (let j = i + 1; j < Math.min(keyed.length, i + window); j += 1) {
      candidates.add(keyed[i].id, keyed[j].id, source);
    }
  }
  return { sorted: keyed.length };
}

/** Character trigram shingles of each token, used as the MinHash set. */
function shingles(tokens) {
  const out = new Set();
  for (const token of tokens) {
    const padded = `#${token}#`;
    for (let i = 0; i + 3 <= padded.length; i += 1) out.add(padded.slice(i, i + 3));
  }
  return out;
}

/**
 * MinHash signatures with LSH banding.
 *
 * For a random hash function h, P[min h(A) = min h(B)] equals the Jaccard
 * similarity of A and B. A signature of `bands * rows` minimum hashes is
 * split into bands; two sets become candidates if any band matches exactly.
 * The collision probability is 1 - (1 - s^rows)^bands, an S-curve with its
 * threshold near (1 / bands)^(1 / rows).
 */
function minHashLsh(records, tokensFn, candidates, {
  bands = 10,
  rows = 5,
  maxBucketSize = 200,
  source = 'minhash-lsh',
} = {}) {
  const numHashes = bands * rows;
  const buckets = new Map();
  for (const record of records) {
    const set = shingles(tokensFn(record));
    if (set.size === 0) continue;
    const base = Array.from(set, (s) => fnv1a32(s));
    const signature = new Uint32Array(numHashes).fill(0xffffffff);
    for (let h = 0; h < numHashes; h += 1) {
      for (const value of base) {
        const mixed = mix32(value, h + 1);
        if (mixed < signature[h]) signature[h] = mixed;
      }
    }
    for (let b = 0; b < bands; b += 1) {
      const key = `${b}:${Array.prototype.join.call(signature.subarray(b * rows, (b + 1) * rows), ',')}`;
      let bucket = buckets.get(key);
      if (!bucket) {
        bucket = [];
        buckets.set(key, bucket);
      }
      bucket.push(record.listingId);
    }
  }
  let skipped = 0;
  for (const ids of buckets.values()) {
    if (ids.length > maxBucketSize) {
      skipped += 1;
    } else if (ids.length > 1) {
      addAllPairsInBucket(ids, candidates, source);
    }
  }
  return { threshold: Number(((1 / bands) ** (1 / rows)).toFixed(3)), skippedBuckets: skipped };
}

/**
 * Visual near-duplicate blocking: every image hash goes into a BK-tree and
 * each listing queries it for hashes within `radius` bits.
 */
function imageBlocking(records, candidates, { radius = 10, source = 'image-bktree' } = {}) {
  const tree = new BKTree(hammingDistance);
  const withHash = records.filter((record) => record.phash !== null && record.phash !== undefined);
  for (const record of withHash) tree.add(record.phash, record.listingId);
  let visits = 0;
  for (const record of withHash) {
    for (const hit of tree.search(record.phash, radius)) {
      candidates.add(record.listingId, hit.item, source);
    }
    visits += tree.lastQueryVisits;
  }
  return {
    indexed: withHash.length,
    averageNodesVisited: withHash.length ? visits / withHash.length : 0,
  };
}

/**
 * Embedding blocking with random-hyperplane LSH band buckets.
 * @param {import('../similarity/embedding').RandomHyperplaneLSH} lsh
 */
function embeddingBlocking(records, lsh, candidates, { maxBucketSize = 200, source = 'embedding-lsh' } = {}) {
  const buckets = new Map();
  for (const record of records) {
    if (!record.signature) continue;
    for (const key of lsh.bandKeys(record.signature)) {
      let bucket = buckets.get(key);
      if (!bucket) {
        bucket = [];
        buckets.set(key, bucket);
      }
      bucket.push(record.listingId);
    }
  }
  let skipped = 0;
  for (const ids of buckets.values()) {
    if (ids.length > maxBucketSize) {
      skipped += 1;
    } else if (ids.length > 1) {
      addAllPairsInBucket(ids, candidates, source);
    }
  }
  return { buckets: buckets.size, skippedBuckets: skipped };
}

/**
 * Runs every blocking pass configured and returns the unioned candidates.
 * @param {object[]} records feature records (with phash and signature set)
 * @param {object} options
 */
function generateCandidates(records, { config, lsh }) {
  const candidates = new CandidateSet();
  const report = {};

  report.standard = standardBlocking(
    records,
    (r) => (r.brand ? `${r.category}|${r.brand}` : null),
    candidates,
    { maxBlockSize: config.blocking.maxBlockSize, window: config.blocking.oversizedBlockWindow },
  );
  report.sortedNeighbourhood = sortedNeighbourhood(
    records,
    (r) => r.coreSorted,
    candidates,
    { window: config.blocking.sortedWindow },
  );
  report.minHash = minHashLsh(
    records,
    (r) => r.coreTokens,
    candidates,
    {
      bands: config.blocking.minHashBands,
      rows: config.blocking.minHashRows,
      maxBucketSize: config.blocking.maxBucketSize,
    },
  );
  report.image = imageBlocking(records, candidates, { radius: config.blocking.imageRadius });
  report.embedding = embeddingBlocking(records, lsh, candidates, { maxBucketSize: config.blocking.maxBucketSize });

  report.candidatePairs = candidates.size;
  report.bySource = candidates.countBySource();
  return { candidates, report };
}

module.exports = {
  CandidateSet,
  pairKey,
  splitPairKey,
  standardBlocking,
  sortedNeighbourhood,
  minHashLsh,
  imageBlocking,
  embeddingBlocking,
  generateCandidates,
  shingles,
};
