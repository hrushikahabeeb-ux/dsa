'use strict';

/**
 * Runs the matching pipeline from the command line and prints a report.
 * Does not require MongoDB or the web server.
 *
 * Usage:
 *   node matching/cli.js            summary, metrics, sweep, review queue
 *   node matching/cli.js --json     full summary and evaluation as JSON
 *   node matching/cli.js --errors   also list false merges and missed matches
 */

const { MatchingService } = require('./service');

const pct = (value) => `${(value * 100).toFixed(1)}%`;

function printTable(rows, columns) {
  const widths = columns.map((c) => Math.max(c.label.length, ...rows.map((r) => String(c.get(r)).length)));
  const line = (cells) => cells.map((cell, i) => String(cell).padEnd(widths[i])).join('  ');
  console.log(line(columns.map((c) => c.label)));
  console.log(line(widths.map((w) => '-'.repeat(w))));
  for (const row of rows) console.log(line(columns.map((c) => c.get(row))));
}

async function main() {
  const args = new Set(process.argv.slice(2));
  const service = new MatchingService();
  const result = await service.getResult();
  const { summary, evaluation } = result;

  if (args.has('--json')) {
    console.log(JSON.stringify({ summary, evaluation }, null, 2));
    return;
  }

  console.log('\nVastra Product Entity-Resolution Pipeline');
  console.log('=========================================\n');
  console.log(`Listings: ${summary.listings.accepted} accepted, ${summary.listings.rejected.length} rejected`);
  console.log(`By seller: ${Object.entries(summary.listings.bySeller).map(([s, n]) => `${s} ${n}`).join(', ')}`);
  console.log(`Multilingual titles translated: ${summary.listings.multilingual}`);
  console.log(`Images hashed: ${summary.listings.withImageHash}\n`);

  console.log('Blocking');
  if (evaluation) {
    const b = evaluation.blocking;
    console.log(`  All possible pairs:  ${b.allPairs}`);
    console.log(`  Candidate pairs:     ${b.candidatePairs}`);
    console.log(`  Reduction ratio:     ${pct(b.reductionRatio)}`);
    console.log(`  Pair completeness:   ${pct(b.pairCompleteness)}`);
  }
  console.log(`  Pairs proposed by pass: ${JSON.stringify(summary.blocking.bySource)}\n`);

  console.log('Decisions');
  console.log(`  ${JSON.stringify(summary.decisions)}  matched relations ${JSON.stringify(summary.matchedRelations)}`);
  console.log(`  Human decisions applied: ${summary.humanDecisionsApplied}, pending review: ${summary.reviewPending}`);
  console.log(`  Unified products: ${summary.clusters.variant.clusters}, product families: ${summary.clusters.family.clusters}`);
  console.log(`  Merges vetoed by cluster guard: ${summary.vetoedMerges}\n`);

  if (evaluation) {
    console.log('Quality against ground truth');
    printTable(
      [
        { level: 'Same item (variant level)', ...evaluation.variant },
        { level: 'Same product (family level)', ...evaluation.family },
      ],
      [
        { label: 'Level', get: (r) => r.level },
        { label: 'Precision', get: (r) => pct(r.precision) },
        { label: 'Recall', get: (r) => pct(r.recall) },
        { label: 'F1', get: (r) => pct(r.f1) },
        { label: 'TP', get: (r) => r.truePositives },
        { label: 'FP', get: (r) => r.falsePositives },
        { label: 'FN', get: (r) => r.falseNegatives },
      ],
    );
    console.log(`Relation accuracy (same vs variant): ${evaluation.relationAccuracy === null ? 'n/a' : pct(evaluation.relationAccuracy)}\n`);

    console.log('Threshold sweep (pairwise, before clustering)');
    printTable(evaluation.sweep, [
      { label: 'Threshold', get: (r) => r.threshold.toFixed(2) },
      { label: 'Item P', get: (r) => pct(r.variant.precision) },
      { label: 'Item R', get: (r) => pct(r.variant.recall) },
      { label: 'Item F1', get: (r) => pct(r.variant.f1) },
      { label: 'Family P', get: (r) => pct(r.family.precision) },
      { label: 'Family R', get: (r) => pct(r.family.recall) },
      { label: 'Family F1', get: (r) => pct(r.family.f1) },
    ]);
    console.log('');

    if (args.has('--errors')) {
      console.log('False merges:', evaluation.errors.falseMerges.length ? evaluation.errors.falseMerges.join(', ') : 'none');
      console.log('Missed matches:', evaluation.errors.missedMatches.length ? evaluation.errors.missedMatches.join(', ') : 'none');
      console.log('');
    }
  }

  const queue = await service.reviewQueue(5);
  console.log(`Review queue (${queue.pending} pending, most uncertain first)`);
  for (const item of queue.items) {
    console.log(`  ${item.score.toFixed(3)}  ${item.relation.padEnd(7)}  ${item.a.title}  <->  ${item.b.title}`);
  }

  console.log(`\nStage timings (ms): ${JSON.stringify(summary.timingsMs)}\n`);
}

main().catch((error) => {
  console.error(`Matching failed: ${error.message}`);
  process.exitCode = 1;
});
