'use strict';

/**
 * Tunable parameters for the matching pipeline. Kept in one place so the
 * precision/recall trade-off can be adjusted and re-evaluated without
 * touching algorithm code. Values were chosen from the threshold sweep
 * produced by `npm run match` (see core/evaluation.js).
 */
const DEFAULT_CONFIG = Object.freeze({
  weights: Object.freeze({
    title: 0.40,
    embedding: 0.25,
    image: 0.20,
    price: 0.15,
  }),
  thresholds: Object.freeze({
    /** Scores at or above this are merged automatically. */
    autoMatch: 0.80,
    /** Scores in [review, autoMatch) go to the human review queue. */
    review: 0.60,
  }),
  penalties: Object.freeze({
    /** Multiplier when brand similarity falls below brandMinimum. */
    brandMismatch: 0.55,
    brandMinimum: 0.85,
    /** Multiplier when normalised categories differ. */
    categoryMismatch: 0.6,
    /** Multiplier when both listings carry different style codes. */
    styleCodeConflict: 0.3,
  }),
  blocking: Object.freeze({
    /** Blocks above this size are compared by sorted window, not all-pairs. */
    maxBlockSize: 100,
    oversizedBlockWindow: 10,
    sortedWindow: 5,
    /** MinHash threshold is about (1 / bands) ^ (1 / rows) = 0.63. */
    minHashBands: 10,
    minHashRows: 5,
    /** LSH buckets above this size are discarded as uninformative. */
    maxBucketSize: 200,
    imageRadius: 10,
  }),
  output: Object.freeze({
    /**
     * Keep feature breakdowns and reasons for non-matching pairs. Useful for
     * inspection on small catalogs; disable for very large runs to cut memory,
     * since non-matches are the overwhelming majority of candidate pairs.
     */
    retainNonMatchDetails: true,
  }),
  embedding: Object.freeze({
    dimensions: 512,
    lshBits: 64,
    /** 4 bands of 16 bits: 65,536 buckets per band. */
    lshBands: 4,
    seed: 20262027,
  }),
});

/**
 * Deep-merges overrides into the defaults. Unknown keys are rejected so a
 * mistyped setting fails loudly instead of being silently ignored.
 */
function resolveConfig(overrides = {}) {
  const merge = (base, patch, path) => {
    const out = { ...base };
    for (const [key, value] of Object.entries(patch || {})) {
      if (!Object.prototype.hasOwnProperty.call(base, key)) {
        throw new Error(`Unknown matching config key: ${path}${key}`);
      }
      out[key] = value && typeof value === 'object' && !Array.isArray(value)
        ? merge(base[key], value, `${path}${key}.`)
        : value;
    }
    return out;
  };
  const config = merge(DEFAULT_CONFIG, overrides, '');
  if (config.thresholds.review > config.thresholds.autoMatch) {
    throw new Error('thresholds.review must not exceed thresholds.autoMatch');
  }
  return config;
}

module.exports = { DEFAULT_CONFIG, resolveConfig };
