'use strict';

const { UnionFind } = require('../ds/unionFind');
const { DECISIONS, RELATIONS } = require('./scoring');

/**
 * Cluster formation.
 *
 * Two Union-Find structures are maintained:
 *   - the variant level groups listings that are the same sellable item
 *     (same product, colour and pack); each group gets a unified product ID;
 *   - the family level groups every variant of one product; each group gets
 *     a family ID, forming the tree Family -> Variants -> Listings.
 *
 * Accepted links are applied in descending score order, as Kruskal's
 * algorithm processes edges, so the most certain evidence shapes clusters
 * first. Every union passes through a guard that inspects the metadata of
 * both clusters and vetoes merges that would put conflicting identifiers
 * into one cluster. This is what stops chains of individually plausible
 * links (A~B, B~C) from producing a false merge of A and C.
 */

function variantMeta(record) {
  return {
    colors: new Set(record.color ? [record.color] : []),
    sizes: new Set(record.size ? [record.size] : []),
    packs: new Set([record.pack]),
    gtins: new Set(record.gtin.valid ? [record.gtin.gtin14] : []),
  };
}

function familyMeta(record) {
  return { styleCodes: new Set(record.styleCode ? [record.styleCode] : []) };
}

function unionSets(a, b) {
  const out = new Set(a);
  for (const item of b) out.add(item);
  return out;
}

function mergeMetaObjects(a, b) {
  const out = {};
  for (const key of Object.keys(a)) out[key] = unionSets(a[key], b[key]);
  return out;
}

function conflictGuard(labels) {
  return (a, b) => {
    for (const [key, label] of Object.entries(labels)) {
      if (unionSets(a[key], b[key]).size > 1) return `would merge different ${label}`;
    }
    return null;
  };
}

/**
 * @param {object[]} records feature records
 * @param {object[]} links final scored links (after human decisions)
 * @param {object} rawListings Map listingId -> raw listing (for display)
 * @param {object} [options]
 * @param {string} [options.preferredSeller] seller whose titles are used as
 *        canonical names when present in a cluster
 */
function buildClusters(records, links, rawListings, { preferredSeller = null } = {}) {
  const variantUF = new UnionFind({
    guard: conflictGuard({ colors: 'colours', sizes: 'sizes', packs: 'pack quantities', gtins: 'GTINs' }),
    mergeMeta: mergeMetaObjects,
  });
  const familyUF = new UnionFind({
    guard: conflictGuard({ styleCodes: 'style codes' }),
    mergeMeta: mergeMetaObjects,
  });
  for (const record of records) {
    variantUF.makeSet(record.listingId, variantMeta(record));
    familyUF.makeSet(record.listingId, familyMeta(record));
  }

  const accepted = links
    .filter((link) => link.decision === DECISIONS.MATCH)
    .sort((x, y) => (y.score - x.score) || (x.key < y.key ? -1 : 1));

  const vetoed = [];
  for (const link of accepted) {
    if (link.relation === RELATIONS.SAME) {
      const result = variantUF.union(link.a, link.b);
      if (!result.merged && result.reason !== 'already-connected') {
        vetoed.push({ key: link.key, level: 'variant', reason: result.reason, score: link.score });
      }
    }
  }
  // Family merges run after variant merges so a family never needs a merge
  // that the variant level refused for a family-level reason.
  for (const link of accepted) {
    const result = familyUF.union(link.a, link.b);
    if (!result.merged && result.reason !== 'already-connected') {
      vetoed.push({ key: link.key, level: 'family', reason: result.reason, score: link.score });
    }
  }

  const recordById = new Map(records.map((r) => [r.listingId, r]));
  const byMinId = (x, y) => (x[0] < y[0] ? -1 : x[0] > y[0] ? 1 : 0);

  const variantComponents = [...variantUF.components().values()]
    .map((members) => members.sort())
    .sort(byMinId);
  const unifiedIdOf = new Map();
  variantComponents.forEach((members, index) => {
    const id = `UPID-${String(index + 1).padStart(6, '0')}`;
    for (const member of members) unifiedIdOf.set(member, id);
  });

  const familyComponents = [...familyUF.components().values()]
    .map((members) => members.sort())
    .sort(byMinId);
  const familyIdOf = new Map();
  familyComponents.forEach((members, index) => {
    const id = `UFID-${String(index + 1).padStart(6, '0')}`;
    for (const member of members) familyIdOf.set(member, id);
  });

  const pickRepresentative = (members) => {
    const preferred = preferredSeller
      ? members.find((id) => rawListings.get(id).seller === preferredSeller)
      : null;
    if (preferred) return preferred;
    return members.reduce((best, id) => (
      recordById.get(id).coreTokens.length > recordById.get(best).coreTokens.length ? id : best
    ));
  };

  const listingView = (id) => {
    const raw = rawListings.get(id);
    return {
      listingId: id,
      seller: raw.seller,
      title: raw.title,
      price: raw.price,
      image: raw.image || null,
    };
  };

  const catalog = familyComponents.map((familyMembers) => {
    const representative = rawListings.get(pickRepresentative(familyMembers));
    const representativeRecord = recordById.get(representative.listingId);
    const variantsById = new Map();
    for (const member of familyMembers) {
      const unifiedId = unifiedIdOf.get(member);
      if (!variantsById.has(unifiedId)) variantsById.set(unifiedId, []);
      variantsById.get(unifiedId).push(member);
    }
    const variants = [...variantsById.entries()].map(([unifiedId, members]) => {
      const meta = variantUF.metaOf(members[0]);
      const prices = members.map((m) => rawListings.get(m).price).filter((p) => p > 0);
      return {
        unifiedId,
        color: [...meta.colors][0] || null,
        size: [...meta.sizes][0] || null,
        pack: [...meta.packs][0] || 1,
        gtins: [...meta.gtins],
        sellers: [...new Set(members.map((m) => rawListings.get(m).seller))].sort(),
        bestPrice: prices.length ? Math.min(...prices) : null,
        listings: members.map(listingView),
      };
    }).sort((x, y) => (x.unifiedId < y.unifiedId ? -1 : 1));

    return {
      familyId: familyIdOf.get(familyMembers[0]),
      title: representative.title,
      brand: representativeRecord.brand,
      category: representativeRecord.category,
      styleCodes: [...familyUF.metaOf(familyMembers[0]).styleCodes],
      listingCount: familyMembers.length,
      variants,
    };
  }).sort((x, y) => (x.familyId < y.familyId ? -1 : 1));

  return {
    unifiedIdOf,
    familyIdOf,
    variantClusters: variantComponents,
    familyClusters: familyComponents,
    catalog,
    vetoed,
    stats: {
      variant: { ...variantUF.stats, clusters: variantComponents.length },
      family: { ...familyUF.stats, clusters: familyComponents.length },
    },
  };
}

module.exports = { buildClusters };
