'use strict';

const { pairKey } = require('../blocking');

/**
 * Evaluation against labelled ground truth.
 *
 * Quality is measured on pairs. A predicted pair is a pair of listings that
 * the system placed in the same cluster; a true pair is a pair the labels
 * say belong together. With hash sets of pair keys every lookup is O(1).
 *
 *   precision = correct merges / all merges made    (penalises false merges)
 *   recall    = correct merges / all true pairs     (penalises missed matches)
 *   F1        = harmonic mean of the two
 *
 * Two levels are reported: variant level (same sellable item) and family
 * level (any variant of the same product).
 */

function pairsWithinClusters(clusters) {
  const pairs = new Set();
  for (const members of clusters) {
    for (let i = 0; i < members.length; i += 1) {
      for (let j = i + 1; j < members.length; j += 1) pairs.add(pairKey(members[i], members[j]));
    }
  }
  return pairs;
}

function groupBy(ids, keyFn) {
  const groups = new Map();
  for (const id of ids) {
    const key = keyFn(id);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(id);
  }
  return [...groups.values()];
}

function precisionRecall(predicted, truth) {
  let truePositives = 0;
  for (const key of predicted) {
    if (truth.has(key)) truePositives += 1;
  }
  const precision = predicted.size === 0 ? 1 : truePositives / predicted.size;
  const recall = truth.size === 0 ? 1 : truePositives / truth.size;
  const f1 = precision + recall === 0 ? 0 : (2 * precision * recall) / (precision + recall);
  return {
    precision: Number(precision.toFixed(4)),
    recall: Number(recall.toFixed(4)),
    f1: Number(f1.toFixed(4)),
    truePositives,
    falsePositives: predicted.size - truePositives,
    falseNegatives: truth.size - truePositives,
  };
}

/**
 * @param {object} input
 * @param {string[]} input.listingIds
 * @param {Map<string, { productId: string, variantKey: string }>} input.groundTruth
 * @param {import('../blocking').CandidateSet} input.candidates
 * @param {object[]} input.links every scored candidate pair
 * @param {object} input.clusters output of buildClusters
 * @returns {object|null} null when no ground truth is available
 */
function evaluate({ listingIds, groundTruth, candidates, links, clusters }) {
  const labelled = listingIds.filter((id) => groundTruth.has(id));
  if (labelled.length === 0) return null;

  const variantTruth = pairsWithinClusters(groupBy(
    labelled,
    (id) => `${groundTruth.get(id).productId}|${groundTruth.get(id).variantKey}`,
  ));
  const familyTruth = pairsWithinClusters(groupBy(labelled, (id) => groundTruth.get(id).productId));

  const variantPredicted = pairsWithinClusters(clusters.variantClusters);
  const familyPredicted = pairsWithinClusters(clusters.familyClusters);

  // Blocking quality: how many true family pairs survived candidate
  // generation (an upper bound on achievable recall), and how much of the
  // quadratic comparison space was avoided.
  const n = listingIds.length;
  const allPairs = (n * (n - 1)) / 2;
  let covered = 0;
  const coveredBySource = {};
  for (const key of familyTruth) {
    const sources = candidates.sourcesOf(key);
    if (sources.size > 0) covered += 1;
    for (const source of sources) coveredBySource[source] = (coveredBySource[source] || 0) + 1;
  }
  const blocking = {
    allPairs,
    candidatePairs: candidates.size,
    reductionRatio: Number((1 - candidates.size / allPairs).toFixed(4)),
    pairCompleteness: Number((familyTruth.size ? covered / familyTruth.size : 1).toFixed(4)),
    truePairsCoveredBySource: coveredBySource,
  };

  // Threshold sweep on pairwise decisions (before clustering), used to pick
  // the auto-match threshold that balances precision against recall.
  const sweep = [];
  for (let t = 0.5; t <= 0.951; t += 0.05) {
    const threshold = Number(t.toFixed(2));
    const familyAtT = new Set();
    const variantAtT = new Set();
    for (const link of links) {
      if (link.score >= threshold) {
        familyAtT.add(link.key);
        if (!link.hasVariantConflict) variantAtT.add(link.key);
      }
    }
    sweep.push({
      threshold,
      variant: precisionRecall(variantAtT, variantTruth),
      family: precisionRecall(familyAtT, familyTruth),
    });
  }

  // Relation accuracy: of the true family pairs that were linked, how often
  // did the system correctly say "same item" versus "variant of"?
  let relationChecked = 0;
  let relationCorrect = 0;
  for (const link of links) {
    if (link.decision !== 'match' || !familyTruth.has(link.key)) continue;
    relationChecked += 1;
    const truthSame = variantTruth.has(link.key);
    if ((link.relation === 'same') === truthSame) relationCorrect += 1;
  }

  const falseMerges = [...variantPredicted].filter((k) => !variantTruth.has(k)).sort();
  const missedMatches = [...variantTruth].filter((k) => !variantPredicted.has(k)).sort();

  return {
    labelledListings: labelled.length,
    truePairs: { variant: variantTruth.size, family: familyTruth.size },
    variant: precisionRecall(variantPredicted, variantTruth),
    family: precisionRecall(familyPredicted, familyTruth),
    relationAccuracy: relationChecked
      ? Number((relationCorrect / relationChecked).toFixed(4))
      : null,
    blocking,
    sweep,
    errors: {
      falseMerges: falseMerges.slice(0, 25),
      missedMatches: missedMatches.slice(0, 25),
    },
  };
}

module.exports = { evaluate, precisionRecall, pairsWithinClusters };
