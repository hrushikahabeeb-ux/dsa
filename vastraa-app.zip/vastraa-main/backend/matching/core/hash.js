'use strict';

/**
 * 32-bit FNV-1a string hash with an optional seed. Fast, dependency free and
 * well distributed for short keys, which is all feature hashing and MinHash
 * need. Returns an unsigned 32-bit integer.
 */
function fnv1a32(str, seed = 0) {
  let hash = (0x811c9dc5 ^ seed) >>> 0;
  for (let i = 0; i < str.length; i += 1) {
    hash ^= str.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return hash >>> 0;
}

/**
 * Final avalanche step from MurmurHash3. Turns one 32-bit hash into an
 * independent-looking one for each seed, which is how MinHash derives many
 * hash functions from a single base hash.
 */
function mix32(value, seed) {
  let h = (value ^ Math.imul(seed, 0x9e3779b1)) >>> 0;
  h ^= h >>> 16;
  h = Math.imul(h, 0x85ebca6b) >>> 0;
  h ^= h >>> 13;
  h = Math.imul(h, 0xc2b2ae35) >>> 0;
  h ^= h >>> 16;
  return h >>> 0;
}

module.exports = { fnv1a32, mix32 };
