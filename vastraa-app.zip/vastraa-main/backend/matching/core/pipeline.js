'use strict';

const fs = require('fs');
const path = require('path');
const { performance } = require('perf_hooks');

const { resolveConfig } = require('../config');
const { ColorIndex, extractFeatures } = require('../text/attributes');
const { normalizeBrand } = require('../text/normalize');
const { HashedTfIdfEmbedder, RandomHyperplaneLSH } = require('../similarity/embedding');
const { perceptualHash, hashToHex } = require('../similarity/imageHash');
const { generateCandidates } = require('../blocking');
const { BinaryHeap } = require('../ds/heap');
const { scorePair, DECISIONS, RELATIONS } = require('./scoring');
const { buildClusters } = require('./clustering');
const { evaluate } = require('./evaluation');

const IMAGE_CONCURRENCY = 8;

/**
 * Perceptual hashes are expensive relative to everything else, so they are
 * cached across runs by absolute path and modification time.
 */
const imageHashCache = new Map();

async function hashImage(absolutePath) {
  const stat = await fs.promises.stat(absolutePath);
  const cacheKey = `${absolutePath}:${stat.mtimeMs}`;
  if (imageHashCache.has(cacheKey)) return imageHashCache.get(cacheKey);
  const hash = await perceptualHash(absolutePath);
  imageHashCache.set(cacheKey, hash);
  return hash;
}

/** Runs async work over items with a fixed number of concurrent workers. */
async function mapWithConcurrency(items, limit, worker) {
  const results = new Array(items.length);
  let next = 0;
  const runners = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) {
      const index = next;
      next += 1;
      results[index] = await worker(items[index], index);
    }
  });
  await Promise.all(runners);
  return results;
}

/**
 * Ingestion: validates raw listings and rejects malformed ones with a
 * reason instead of failing the whole run.
 */
function ingest(listings) {
  const accepted = [];
  const rejected = [];
  const seen = new Set();
  for (const listing of listings) {
    const id = listing && listing.listingId;
    if (!id || typeof id !== 'string') {
      rejected.push({ listingId: id || null, reason: 'missing listingId' });
    } else if (id.includes('::')) {
      rejected.push({ listingId: id, reason: 'listingId must not contain "::"' });
    } else if (seen.has(id)) {
      rejected.push({ listingId: id, reason: 'duplicate listingId' });
    } else if (!listing.title || !String(listing.title).trim()) {
      rejected.push({ listingId: id, reason: 'missing title' });
    } else {
      seen.add(id);
      accepted.push(listing);
    }
  }
  return { accepted, rejected };
}

/**
 * Applies stored human decisions on top of machine scores. A human decision
 * always wins over the model, in both directions.
 */
function applyHumanDecisions(links, reviewStore) {
  if (!reviewStore) return 0;
  let applied = 0;
  for (const link of links) {
    const human = reviewStore.get(link.key);
    if (!human) continue;
    applied += 1;
    link.machineDecision = link.decision;
    link.human = human;
    if (human.decision === 'accept') {
      link.decision = DECISIONS.MATCH;
      if (human.relation === RELATIONS.SAME || human.relation === RELATIONS.VARIANT) {
        link.relation = human.relation;
      }
      link.reasons = ['Confirmed by reviewer', ...link.reasons];
    } else {
      link.decision = DECISIONS.NON_MATCH;
      link.reasons = ['Rejected by reviewer', ...link.reasons];
    }
  }
  return applied;
}

/**
 * Review priority: the pairs the model is least sure about come first,
 * measured as distance from the middle of the review band.
 */
function buildReviewQueue(links, thresholds) {
  const midpoint = (thresholds.review + thresholds.autoMatch) / 2;
  const pending = links
    .filter((link) => link.decision === DECISIONS.REVIEW)
    .map((link) => ({ link, uncertainty: Math.abs(link.score - midpoint) }));
  return BinaryHeap.from(pending, (x, y) => (x.uncertainty - y.uncertainty) || (x.link.key < y.link.key ? -1 : 1));
}

/**
 * Runs the full entity-resolution pipeline.
 *
 * @param {object} input
 * @param {object[]} input.listings raw listings from every source catalog
 * @param {Map<string, object>} [input.groundTruth] labels for evaluation
 * @param {import('./reviewStore').ReviewStore} [input.reviewStore]
 * @param {string} [input.imageRoot] directory image paths are relative to
 * @param {object} [input.config] overrides for config.js defaults
 * @param {string} [input.preferredSeller] seller used for canonical names
 * @param {{ warn: Function }} [input.logger]
 */
async function runPipeline({
  listings,
  groundTruth = new Map(),
  reviewStore = null,
  imageRoot = null,
  config: overrides = {},
  preferredSeller = null,
  logger = console,
}) {
  if (!Array.isArray(listings)) throw new TypeError('listings must be an array');
  const config = resolveConfig(overrides);
  const timings = {};
  const time = async (label, fn) => {
    const start = performance.now();
    const value = await fn();
    timings[label] = Number((performance.now() - start).toFixed(2));
    return value;
  };

  const { accepted, rejected } = await time('ingestion', () => ingest(listings));
  const rawListings = new Map(accepted.map((listing) => [listing.listingId, listing]));

  const records = await time('normalization', () => {
    const colorIndex = new ColorIndex(
      accepted.map((l) => l.attributes && l.attributes.color).filter(Boolean),
    );
    const knownBrands = [...new Set(accepted.map((l) => normalizeBrand(l.brand)).filter(Boolean))]
      .sort((x, y) => y.length - x.length);
    return accepted.map((listing) => extractFeatures(listing, { colorIndex, knownBrands }));
  });

  const lsh = await time('embeddings', () => {
    const embedder = new HashedTfIdfEmbedder({ dimensions: config.embedding.dimensions });
    embedder.fit(records.map((r) => r.coreTokens));
    const hyperplanes = new RandomHyperplaneLSH({
      dimensions: config.embedding.dimensions,
      bits: config.embedding.lshBits,
      bands: config.embedding.lshBands,
      seed: config.embedding.seed,
    });
    for (const record of records) {
      record.vector = embedder.embed(record.coreTokens);
      record.signature = hyperplanes.signature(record.vector);
    }
    return hyperplanes;
  });

  const imageFailures = [];
  await time('imageHashing', () => mapWithConcurrency(records, IMAGE_CONCURRENCY, async (record) => {
    record.phash = null;
    if (!record.image || !imageRoot) return;
    const absolute = path.resolve(imageRoot, record.image);
    if (!absolute.startsWith(path.resolve(imageRoot) + path.sep)) {
      imageFailures.push({ listingId: record.listingId, reason: 'image path escapes image root' });
      return;
    }
    try {
      record.phash = await hashImage(absolute);
    } catch (error) {
      imageFailures.push({ listingId: record.listingId, reason: error.message });
    }
  }));
  if (imageFailures.length > 0 && logger) {
    logger.warn(`[matching] ${imageFailures.length} image(s) could not be hashed`);
  }

  const { candidates, report: blockingReport } = await time(
    'blocking',
    () => generateCandidates(records, { config, lsh }),
  );

  const recordById = new Map(records.map((r) => [r.listingId, r]));
  const links = await time('scoring', () => {
    const out = [];
    for (const key of candidates.keys()) {
      const [a, b] = key.split('::');
      const link = scorePair(recordById.get(a), recordById.get(b), config);
      if (!config.output.retainNonMatchDetails && link.decision === DECISIONS.NON_MATCH) {
        out.push({
          key: link.key,
          a: link.a,
          b: link.b,
          score: link.score,
          decision: link.decision,
          relation: link.relation,
          rule: link.rule,
          hasVariantConflict: link.hasVariantConflict,
          features: null,
          reasons: [],
          blockingSources: [],
        });
        continue;
      }
      link.blockingSources = [...candidates.sourcesOf(key)].sort();
      out.push(link);
    }
    return out;
  });

  const humanDecisionsApplied = applyHumanDecisions(links, reviewStore);
  const reviewQueue = buildReviewQueue(links, config.thresholds);

  const clusters = await time('clustering', () => buildClusters(records, links, rawListings, { preferredSeller }));

  const evaluation = await time('evaluation', () => evaluate({
    listingIds: records.map((r) => r.listingId),
    groundTruth,
    candidates,
    links,
    clusters,
  }));

  const decisionCounts = { match: 0, review: 0, 'non-match': 0 };
  const relationCounts = { same: 0, variant: 0 };
  for (const link of links) {
    decisionCounts[link.decision] += 1;
    if (link.decision === DECISIONS.MATCH) relationCounts[link.relation] += 1;
  }

  const multilingualListings = records.filter(
    (r) => r.multilingual.translated + r.multilingual.transliterated > 0,
  ).length;

  return {
    generatedAt: new Date().toISOString(),
    config,
    records,
    recordById,
    rawListings,
    links,
    linkByKey: new Map(links.map((link) => [link.key, link])),
    reviewQueue,
    clusters,
    evaluation,
    summary: {
      listings: {
        received: listings.length,
        accepted: accepted.length,
        rejected,
        bySeller: accepted.reduce((acc, l) => ({ ...acc, [l.seller]: (acc[l.seller] || 0) + 1 }), {}),
        multilingual: multilingualListings,
        withImageHash: records.filter((r) => r.phash !== null).length,
        imageFailures,
      },
      blocking: blockingReport,
      decisions: decisionCounts,
      matchedRelations: relationCounts,
      humanDecisionsApplied,
      reviewPending: reviewQueue.size,
      clusters: clusters.stats,
      vetoedMerges: clusters.vetoed.length,
      timingsMs: timings,
    },
    imageHashes: new Map(records.filter((r) => r.phash !== null).map((r) => [r.listingId, hashToHex(r.phash)])),
  };
}

module.exports = { runPipeline, ingest, applyHumanDecisions, buildReviewQueue };
