'use strict';

/**
 * Seeded pseudo-random number generation. Every randomised component
 * (hyperplanes, dataset generation) takes an explicit seed so that runs are
 * reproducible and results in the report can be regenerated exactly.
 */

/** Mulberry32: small, fast 32-bit PRNG returning floats in [0, 1). */
function mulberry32(seed) {
  let state = seed >>> 0;
  return function next() {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Standard normal sample via the Box-Muller transform. */
function gaussian(rng) {
  let u = 0;
  while (u === 0) u = rng();
  const v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

/** Uniform integer in [min, max]. */
function randomInt(rng, min, max) {
  return min + Math.floor(rng() * (max - min + 1));
}

/** Uniformly chosen element. */
function pick(rng, items) {
  return items[Math.floor(rng() * items.length)];
}

module.exports = { mulberry32, gaussian, randomInt, pick };
