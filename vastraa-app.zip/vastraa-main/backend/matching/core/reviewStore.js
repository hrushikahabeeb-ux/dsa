'use strict';

const fs = require('fs');
const path = require('path');

const VALID_DECISIONS = new Set(['accept', 'reject']);

/**
 * Human review decisions keyed by pair key, persisted as JSON.
 *
 * Lookups go through an in-memory Map, so the pipeline checks every
 * candidate pair against past decisions in O(1) and a reviewer is never
 * asked the same question twice. Writes go to a temporary file that is then
 * renamed over the original; rename is atomic on POSIX file systems, so a
 * crash mid-write cannot leave a truncated decisions file behind.
 */
class ReviewStore {
  /**
   * @param {string|null} filePath null keeps decisions in memory only
   */
  constructor(filePath) {
    this._filePath = filePath;
    this._decisions = new Map();
    this._load();
  }

  get size() {
    return this._decisions.size;
  }

  get(key) {
    return this._decisions.get(key) || null;
  }

  /** @returns {Map<string, object>} a copy of all decisions */
  all() {
    return new Map(this._decisions);
  }

  /**
   * @param {string} key pair key
   * @param {'accept'|'reject'} decision
   * @param {object} [details]
   * @param {string} [details.reviewer]
   * @param {string} [details.relation] relation the reviewer confirmed
   */
  set(key, decision, { reviewer = 'anonymous', relation = null } = {}) {
    if (typeof key !== 'string' || !key.includes('::')) {
      throw new TypeError('Review decisions require a valid pair key');
    }
    if (!VALID_DECISIONS.has(decision)) {
      throw new RangeError(`Decision must be one of: ${[...VALID_DECISIONS].join(', ')}`);
    }
    const entry = {
      decision,
      relation,
      reviewer: String(reviewer).slice(0, 120),
      decidedAt: new Date().toISOString(),
    };
    this._decisions.set(key, entry);
    this._save();
    return entry;
  }

  remove(key) {
    const removed = this._decisions.delete(key);
    if (removed) this._save();
    return removed;
  }

  _load() {
    if (!this._filePath || !fs.existsSync(this._filePath)) return;
    try {
      const parsed = JSON.parse(fs.readFileSync(this._filePath, 'utf8'));
      for (const [key, entry] of Object.entries(parsed.decisions || {})) {
        if (entry && VALID_DECISIONS.has(entry.decision)) this._decisions.set(key, entry);
      }
    } catch (error) {
      throw new Error(`Could not read review decisions from ${this._filePath}: ${error.message}`);
    }
  }

  _save() {
    if (!this._filePath) return;
    fs.mkdirSync(path.dirname(this._filePath), { recursive: true });
    const payload = JSON.stringify({ version: 1, decisions: Object.fromEntries(this._decisions) }, null, 2);
    const tempPath = `${this._filePath}.${process.pid}.tmp`;
    fs.writeFileSync(tempPath, payload);
    fs.renameSync(tempPath, this._filePath);
  }
}

module.exports = { ReviewStore, VALID_DECISIONS };
