'use strict';

const {
  levenshteinRatio,
  softJaccard,
  jaroWinkler,
  priceProximity,
} = require('../similarity/string');
const { cosine } = require('../similarity/embedding');
const { hashSimilarity } = require('../similarity/imageHash');
const { pairKey } = require('../blocking');

const DECISIONS = Object.freeze({
  MATCH: 'match',
  REVIEW: 'review',
  NON_MATCH: 'non-match',
});

const RELATIONS = Object.freeze({
  SAME: 'same',
  VARIANT: 'variant',
});

function round(value, digits = 4) {
  if (value === null || value === undefined) return null;
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
}

/**
 * Variant attributes that distinguish sellable variants of one product.
 * Only attributes known on both sides can conflict: a missing colour is
 * absence of evidence, not a difference.
 * @returns {string[]} human-readable conflicts
 */
function variantConflicts(a, b) {
  const conflicts = [];
  if (a.color && b.color && a.color !== b.color) conflicts.push(`colour differs (${a.color} vs ${b.color})`);
  if (a.size && b.size && a.size !== b.size) conflicts.push(`size differs (${a.size} vs ${b.size})`);
  if (a.pack !== b.pack) conflicts.push(`pack quantity differs (${a.pack} vs ${b.pack})`);
  if (a.gtin.valid && b.gtin.valid && a.gtin.gtin14 !== b.gtin.gtin14) conflicts.push('GTINs differ');
  return conflicts;
}

/**
 * Computes the individual similarity features for a pair.
 */
function computeFeatures(a, b) {
  const titleLevenshtein = levenshteinRatio(a.coreSorted, b.coreSorted);
  const titleJaccard = softJaccard(a.coreTokenSet, b.coreTokenSet);
  return {
    brand: a.brand && b.brand ? jaroWinkler(a.brand, b.brand) : null,
    titleLevenshtein,
    titleJaccard,
    title: 0.5 * titleLevenshtein + 0.5 * titleJaccard,
    embedding: a.vector && b.vector ? cosine(a.vector, b.vector) : null,
    image: a.phash !== null && a.phash !== undefined && b.phash !== null && b.phash !== undefined
      ? hashSimilarity(a.phash, b.phash)
      : null,
    price: priceProximity(a.price, b.price),
    sameCategory: a.category === b.category,
  };
}

/**
 * Weighted average over the features available for this pair. Weights of
 * missing features (no image, no price) are redistributed proportionally
 * so a listing without a photo is not penalised for it.
 */
function weightedScore(features, weights) {
  const parts = [
    ['title', features.title],
    ['embedding', features.embedding],
    ['image', features.image],
    ['price', features.price],
  ];
  let total = 0;
  let weightSum = 0;
  for (const [name, value] of parts) {
    if (value === null || value === undefined) continue;
    total += weights[name] * value;
    weightSum += weights[name];
  }
  return weightSum === 0 ? 0 : total / weightSum;
}

function decide(score, thresholds) {
  if (score >= thresholds.autoMatch) return DECISIONS.MATCH;
  if (score >= thresholds.review) return DECISIONS.REVIEW;
  return DECISIONS.NON_MATCH;
}

/**
 * Scores one candidate pair.
 *
 * Order of evaluation:
 *   1. Deterministic rules on identifiers (GTIN, style code).
 *   2. Weighted fuzzy score over title, embedding, image and price.
 *   3. Penalties for brand, category or style-code disagreement.
 *   4. Threshold decision: match, review or non-match.
 *   5. Variant check: a match whose variant attributes conflict is linked
 *      as "variant of" rather than merged as the same item.
 *
 * @param {object} a feature record
 * @param {object} b feature record
 * @param {object} config resolved matching config
 */
function scorePair(a, b, config) {
  const features = computeFeatures(a, b);
  const reasons = [];
  const conflicts = variantConflicts(a, b);
  let rule = null;
  let score;
  let decision;

  if (a.gtin.present && !a.gtin.valid) reasons.push(`GTIN on ${a.listingId} rejected (${a.gtin.reason})`);
  if (b.gtin.present && !b.gtin.valid) reasons.push(`GTIN on ${b.listingId} rejected (${b.gtin.reason})`);

  const gtinExact = a.gtin.valid && b.gtin.valid && a.gtin.gtin14 === b.gtin.gtin14;

  if (gtinExact) {
    rule = 'gtin-exact';
    const attributeConflicts = conflicts.filter((c) => c !== 'GTINs differ');
    if (attributeConflicts.length > 0) {
      // Identical GTINs should mean identical items. Conflicting attributes
      // point to a data-entry error, which a person should resolve.
      score = (config.thresholds.review + config.thresholds.autoMatch) / 2;
      decision = DECISIONS.REVIEW;
      reasons.push('Identical GTIN but conflicting attributes');
    } else {
      score = 1;
      decision = DECISIONS.MATCH;
      reasons.push('Identical valid GTIN');
    }
  } else {
    score = weightedScore(features, config.weights);

    if (features.brand !== null && features.brand < config.penalties.brandMinimum) {
      score *= config.penalties.brandMismatch;
      reasons.push(`Brand mismatch (${a.brand || 'unknown'} vs ${b.brand || 'unknown'})`);
    }
    if (!features.sameCategory) {
      score *= config.penalties.categoryMismatch;
      reasons.push(`Category mismatch (${a.category} vs ${b.category})`);
    }
    if (a.styleCode && b.styleCode) {
      if (a.styleCode === b.styleCode) {
        rule = 'style-code-exact';
        score = Math.max(score, 0.95);
        reasons.push(`Same style code ${a.styleCode}`);
      } else {
        score *= config.penalties.styleCodeConflict;
        reasons.push(`Different style codes (${a.styleCode} vs ${b.styleCode})`);
      }
    }
    decision = decide(score, config.thresholds);
  }

  const relation = decision !== DECISIONS.NON_MATCH && conflicts.length > 0 && !(gtinExact && decision === DECISIONS.MATCH)
    ? RELATIONS.VARIANT
    : RELATIONS.SAME;
  if (relation === RELATIONS.VARIANT) reasons.push(...conflicts);

  if (features.title >= 0.8) reasons.push('Titles closely match');
  if (features.image !== null && features.image >= 0.85) reasons.push('Images are near-identical');

  return {
    key: pairKey(a.listingId, b.listingId),
    a: a.listingId,
    b: b.listingId,
    score: round(score),
    decision,
    relation,
    rule,
    hasVariantConflict: conflicts.length > 0 && !gtinExact,
    features: {
      brand: round(features.brand),
      title: round(features.title),
      titleLevenshtein: round(features.titleLevenshtein),
      titleJaccard: round(features.titleJaccard),
      embedding: round(features.embedding),
      image: round(features.image),
      price: round(features.price),
      sameCategory: features.sameCategory,
    },
    reasons,
  };
}

module.exports = {
  scorePair,
  variantConflicts,
  computeFeatures,
  weightedScore,
  DECISIONS,
  RELATIONS,
};
