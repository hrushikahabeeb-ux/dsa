'use strict';

/**
 * Burkhard-Keller tree for range queries in a discrete metric space.
 *
 * Every child edge is labelled with the distance between the child and its
 * parent. For a query q with radius r, the triangle inequality guarantees
 * that matches under a node at distance d from q can only live on edges
 * labelled in [d - r, d + r], so whole subtrees are pruned without being
 * visited. With Hamming distance over 64-bit perceptual hashes this finds
 * visually near-identical images without comparing against every image.
 */
class BKTree {
  /**
   * @param {(a: any, b: any) => number} distance a metric returning
   *        non-negative integers
   */
  constructor(distance) {
    if (typeof distance !== 'function') {
      throw new TypeError('BKTree requires a distance function');
    }
    this._distance = distance;
    this._root = null;
    this._size = 0;
    this.lastQueryVisits = 0;
  }

  get size() {
    return this._size;
  }

  /**
   * @param {any} key value the metric operates on
   * @param {any} item payload returned by searches
   */
  add(key, item) {
    const node = { key, items: [item], children: new Map() };
    if (!this._root) {
      this._root = node;
      this._size += 1;
      return;
    }
    let current = this._root;
    for (;;) {
      const d = this._distance(key, current.key);
      if (d === 0) {
        current.items.push(item);
        this._size += 1;
        return;
      }
      const child = current.children.get(d);
      if (!child) {
        current.children.set(d, node);
        this._size += 1;
        return;
      }
      current = child;
    }
  }

  /**
   * Returns every stored item within `radius` of `key`.
   * @returns {Array<{ item: any, distance: number }>}
   */
  search(key, radius) {
    const results = [];
    this.lastQueryVisits = 0;
    if (!this._root) return results;
    const stack = [this._root];
    while (stack.length > 0) {
      const node = stack.pop();
      this.lastQueryVisits += 1;
      const d = this._distance(key, node.key);
      if (d <= radius) {
        for (const item of node.items) results.push({ item, distance: d });
      }
      const low = d - radius;
      const high = d + radius;
      for (const [edge, child] of node.children) {
        if (edge >= low && edge <= high) stack.push(child);
      }
    }
    return results;
  }
}

module.exports = { BKTree };
