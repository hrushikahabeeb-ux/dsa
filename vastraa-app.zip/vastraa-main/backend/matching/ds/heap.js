'use strict';

/**
 * Array-backed binary heap.
 *
 * The ordering is defined by a comparator: compare(a, b) < 0 means `a` has
 * higher priority than `b` and therefore sits closer to the root. Passing
 * (a, b) => a - b yields a min-heap; (a, b) => b - a yields a max-heap.
 *
 * Complexity:
 *   push / pop      O(log n)
 *   peek            O(1)
 *   BinaryHeap.from O(n)   (bottom-up heapify)
 *   topK(k)         O(k log n) on a copy, the heap itself is untouched
 */
class BinaryHeap {
  /**
   * @param {(a: any, b: any) => number} compare
   */
  constructor(compare) {
    if (typeof compare !== 'function') {
      throw new TypeError('BinaryHeap requires a comparator function');
    }
    this._compare = compare;
    this._items = [];
  }

  /**
   * Builds a heap from an existing array in linear time.
   * @param {Array<any>} items
   * @param {(a: any, b: any) => number} compare
   * @returns {BinaryHeap}
   */
  static from(items, compare) {
    const heap = new BinaryHeap(compare);
    heap._items = Array.from(items);
    for (let i = (heap._items.length >> 1) - 1; i >= 0; i -= 1) {
      heap._siftDown(i);
    }
    return heap;
  }

  get size() {
    return this._items.length;
  }

  isEmpty() {
    return this._items.length === 0;
  }

  peek() {
    return this._items.length > 0 ? this._items[0] : undefined;
  }

  push(item) {
    this._items.push(item);
    this._siftUp(this._items.length - 1);
    return this;
  }

  pop() {
    const items = this._items;
    if (items.length === 0) return undefined;
    const top = items[0];
    const last = items.pop();
    if (items.length > 0) {
      items[0] = last;
      this._siftDown(0);
    }
    return top;
  }

  /**
   * Pushes an item while keeping the heap at most `capacity` long. Used for
   * bounded top-k selection: with a min-heap on score, the root is the
   * weakest of the current best k, so a better candidate replaces it.
   * @returns {boolean} whether the item was retained
   */
  pushBounded(item, capacity) {
    if (capacity <= 0) return false;
    if (this._items.length < capacity) {
      this.push(item);
      return true;
    }
    if (this._compare(this._items[0], item) < 0) {
      this._items[0] = item;
      this._siftDown(0);
      return true;
    }
    return false;
  }

  /**
   * Returns the k highest-priority items in priority order without
   * modifying this heap.
   */
  topK(k) {
    const copy = new BinaryHeap(this._compare);
    copy._items = this._items.slice();
    const out = [];
    while (out.length < k && copy.size > 0) out.push(copy.pop());
    return out;
  }

  /** Drains all items in priority order (destructive). */
  drain() {
    const out = [];
    while (this._items.length > 0) out.push(this.pop());
    return out;
  }

  toArray() {
    return this._items.slice();
  }

  _siftUp(index) {
    const items = this._items;
    const item = items[index];
    let i = index;
    while (i > 0) {
      const parent = (i - 1) >> 1;
      if (this._compare(item, items[parent]) >= 0) break;
      items[i] = items[parent];
      i = parent;
    }
    items[i] = item;
  }

  _siftDown(index) {
    const items = this._items;
    const length = items.length;
    const item = items[index];
    let i = index;
    for (;;) {
      const left = 2 * i + 1;
      if (left >= length) break;
      const right = left + 1;
      const child = right < length && this._compare(items[right], items[left]) < 0 ? right : left;
      if (this._compare(items[child], item) >= 0) break;
      items[i] = items[child];
      i = child;
    }
    items[i] = item;
  }
}

module.exports = { BinaryHeap };
