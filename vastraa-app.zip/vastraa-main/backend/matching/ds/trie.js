'use strict';

/**
 * Character trie keyed on Unicode code points.
 *
 * The central operation is longestPrefixMatch(text, start): starting at a
 * position in a string, walk the trie as far as the text allows and report
 * the longest dictionary key that ends along that walk. This lets the
 * normaliser translate unsegmented or inflected text greedily, the same way
 * a maximal-munch tokenizer works, in O(L) per match where L is the length
 * of the longest key.
 */
class TrieNode {
  constructor() {
    this.children = new Map();
    this.terminal = false;
    this.value = undefined;
  }
}

class Trie {
  constructor() {
    this._root = new TrieNode();
    this._size = 0;
  }

  get size() {
    return this._size;
  }

  insert(key, value) {
    if (typeof key !== 'string' || key.length === 0) {
      throw new TypeError('Trie keys must be non-empty strings');
    }
    let node = this._root;
    for (const ch of key) {
      let next = node.children.get(ch);
      if (!next) {
        next = new TrieNode();
        node.children.set(ch, next);
      }
      node = next;
    }
    if (!node.terminal) this._size += 1;
    node.terminal = true;
    node.value = value;
    return this;
  }

  get(key) {
    const node = this._walk(key);
    return node && node.terminal ? node.value : undefined;
  }

  has(key) {
    const node = this._walk(key);
    return Boolean(node && node.terminal);
  }

  /**
   * @param {string} text
   * @param {number} start index into `text` (UTF-16 code unit offset)
   * @returns {{ value: any, length: number } | null}
   *          `length` is measured in UTF-16 code units so callers can slice.
   */
  longestPrefixMatch(text, start = 0) {
    let node = this._root;
    let best = null;
    let i = start;
    while (i < text.length) {
      const codePoint = text.codePointAt(i);
      const ch = String.fromCodePoint(codePoint);
      node = node.children.get(ch);
      if (!node) break;
      i += ch.length;
      if (node.terminal) best = { value: node.value, length: i - start };
    }
    return best;
  }

  _walk(key) {
    let node = this._root;
    for (const ch of key) {
      node = node.children.get(ch);
      if (!node) return null;
    }
    return node;
  }
}

module.exports = { Trie };
