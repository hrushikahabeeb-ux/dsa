'use strict';

/**
 * Disjoint Set Union (Union-Find) over arbitrary string identifiers.
 *
 * Uses path compression (iterative, so deep trees cannot overflow the stack)
 * and union by rank, giving amortised O(alpha(n)) per operation, where alpha
 * is the inverse Ackermann function and is at most 4 for any practical n.
 *
 * Each set root carries a metadata object. A caller-supplied guard can veto a
 * union after inspecting both roots' metadata. Entity resolution relies on
 * this to stop transitive false merges: if A~B and B~C are both accepted but
 * the cluster {A, B} and the listing C carry conflicting identifiers, the
 * guard rejects the second union instead of silently chaining them together.
 */
class UnionFind {
  /**
   * @param {object} [options]
   * @param {(metaA: any, metaB: any) => string|null} [options.guard]
   *        Returns null to allow the merge, or a string explaining the veto.
   * @param {(metaA: any, metaB: any) => any} [options.mergeMeta]
   *        Combines metadata of two roots into the metadata of the new root.
   */
  constructor(options = {}) {
    this._index = new Map();
    this._ids = [];
    this._parent = [];
    this._rank = [];
    this._size = [];
    this._meta = [];
    this._guard = options.guard || null;
    this._mergeMeta = options.mergeMeta || null;
    this.stats = { unions: 0, vetoed: 0, redundant: 0 };
  }

  get count() {
    return this._ids.length;
  }

  has(id) {
    return this._index.has(id);
  }

  /**
   * Registers a singleton set. Re-registering an existing id is a no-op.
   */
  makeSet(id, meta = null) {
    if (this._index.has(id)) return;
    const i = this._ids.length;
    this._index.set(id, i);
    this._ids.push(id);
    this._parent.push(i);
    this._rank.push(0);
    this._size.push(1);
    this._meta.push(meta);
  }

  /**
   * Returns the representative id of the set containing `id`.
   */
  find(id) {
    const i = this._indexOf(id);
    return this._ids[this._findIndex(i)];
  }

  connected(a, b) {
    return this._findIndex(this._indexOf(a)) === this._findIndex(this._indexOf(b));
  }

  sizeOf(id) {
    return this._size[this._findIndex(this._indexOf(id))];
  }

  metaOf(id) {
    return this._meta[this._findIndex(this._indexOf(id))];
  }

  /**
   * Merges the sets containing `a` and `b`.
   * @returns {{ merged: boolean, reason: string|null }}
   */
  union(a, b) {
    let rootA = this._findIndex(this._indexOf(a));
    let rootB = this._findIndex(this._indexOf(b));
    if (rootA === rootB) {
      this.stats.redundant += 1;
      return { merged: false, reason: 'already-connected' };
    }

    if (this._guard) {
      const veto = this._guard(this._meta[rootA], this._meta[rootB]);
      if (veto) {
        this.stats.vetoed += 1;
        return { merged: false, reason: veto };
      }
    }

    if (this._rank[rootA] < this._rank[rootB]) {
      const tmp = rootA;
      rootA = rootB;
      rootB = tmp;
    }
    this._parent[rootB] = rootA;
    this._size[rootA] += this._size[rootB];
    if (this._rank[rootA] === this._rank[rootB]) this._rank[rootA] += 1;
    if (this._mergeMeta) {
      this._meta[rootA] = this._mergeMeta(this._meta[rootA], this._meta[rootB]);
    }
    this._meta[rootB] = null;
    this.stats.unions += 1;
    return { merged: true, reason: null };
  }

  /**
   * Groups every registered id by its set.
   * @returns {Map<string, string[]>} representative id -> member ids
   */
  components() {
    const groups = new Map();
    for (let i = 0; i < this._ids.length; i += 1) {
      const root = this._ids[this._findIndex(i)];
      let members = groups.get(root);
      if (!members) {
        members = [];
        groups.set(root, members);
      }
      members.push(this._ids[i]);
    }
    return groups;
  }

  _indexOf(id) {
    const i = this._index.get(id);
    if (i === undefined) {
      throw new Error(`UnionFind: unknown id "${id}"`);
    }
    return i;
  }

  _findIndex(i) {
    let root = i;
    while (this._parent[root] !== root) root = this._parent[root];
    let node = i;
    while (this._parent[node] !== root) {
      const next = this._parent[node];
      this._parent[node] = root;
      node = next;
    }
    return root;
  }
}

module.exports = { UnionFind };
