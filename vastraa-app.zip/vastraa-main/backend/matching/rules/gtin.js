'use strict';

/**
 * GTIN handling (covers UPC-A = GTIN-12, EAN-13 = GTIN-13, GTIN-8, GTIN-14).
 *
 * All four formats share one check-digit algorithm (GS1 mod-10): counting
 * from the rightmost digit of the body (the digit just left of the check
 * digit), digits are weighted 3, 1, 3, 1, ...; the check digit brings the
 * weighted sum up to the next multiple of 10. Codes of different lengths
 * are compared by left-padding with zeros to 14 digits, which is how GS1
 * defines their equivalence (a UPC-A and its EAN-13 form are the same GTIN).
 */

const VALID_LENGTHS = new Set([8, 12, 13, 14]);

/**
 * @param {string} body digits without the check digit
 * @returns {number} the check digit 0-9
 */
function computeCheckDigit(body) {
  if (!/^\d+$/.test(body)) {
    throw new TypeError('GTIN body must contain digits only');
  }
  let sum = 0;
  let weight = 3;
  for (let i = body.length - 1; i >= 0; i -= 1) {
    sum += Number(body[i]) * weight;
    weight = weight === 3 ? 1 : 3;
  }
  return (10 - (sum % 10)) % 10;
}

/**
 * Validates and canonicalises a raw identifier string.
 * @param {string|number|null|undefined} raw
 * @returns {{
 *   present: boolean,  a value was supplied
 *   valid: boolean,    correct length and check digit
 *   gtin14: string|null canonical 14-digit form when valid
 *   reason: string|null why an identifier was rejected
 * }}
 */
function parseGtin(raw) {
  if (raw === null || raw === undefined || String(raw).trim() === '') {
    return { present: false, valid: false, gtin14: null, reason: null };
  }
  const digits = String(raw).replace(/[\s-]/g, '');
  if (!/^\d+$/.test(digits)) {
    return { present: true, valid: false, gtin14: null, reason: 'non-numeric' };
  }
  if (!VALID_LENGTHS.has(digits.length)) {
    return { present: true, valid: false, gtin14: null, reason: `invalid-length-${digits.length}` };
  }
  const body = digits.slice(0, -1);
  const check = Number(digits[digits.length - 1]);
  if (computeCheckDigit(body) !== check) {
    return { present: true, valid: false, gtin14: null, reason: 'bad-check-digit' };
  }
  return { present: true, valid: true, gtin14: digits.padStart(14, '0'), reason: null };
}

/**
 * Builds a valid GTIN-13 from a 12-digit body. Used by the dataset
 * generator and by tests.
 */
function makeGtin13(body12) {
  const body = String(body12);
  if (!/^\d{12}$/.test(body)) {
    throw new TypeError('GTIN-13 body must be exactly 12 digits');
  }
  return body + computeCheckDigit(body);
}

module.exports = { computeCheckDigit, parseGtin, makeGtin13 };
