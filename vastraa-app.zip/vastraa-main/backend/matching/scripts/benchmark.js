'use strict';

/**
 * Scalability benchmark.
 *
 * Generates a synthetic catalog of N listings (products listed one to four
 * times by different sellers, with typos, reordering and price noise), runs
 * the pipeline without images, and reports stage timings, the number of
 * candidate pairs against the N(N - 1) / 2 all-pairs baseline, and quality.
 *
 * Usage: node matching/scripts/benchmark.js [--sizes 1000,10000,50000]
 */

const { performance } = require('perf_hooks');
const { runPipeline } = require('../core/pipeline');
const { mulberry32, randomInt, pick } = require('../core/random');

const ADJECTIVES = [
  'classic', 'printed', 'embroidered', 'slim', 'relaxed', 'floral', 'striped', 'checked', 'solid',
  'washed', 'stretch', 'cropped', 'oversized', 'tailored', 'pleated', 'ribbed', 'quilted', 'textured',
  'handloom', 'block', 'bandhani', 'ikat', 'chikankari', 'zari', 'sequinned', 'tiered', 'layered',
  'ruffled', 'belted', 'hooded', 'padded', 'lightweight', 'thermal', 'organic', 'linen', 'cotton',
  'silk', 'rayon', 'denim', 'wool', 'velvet', 'georgette', 'chiffon', 'satin', 'khadi', 'modal',
];
const TYPES = [
  'kurti', 'kurta', 'saree', 'lehenga', 'shirt', 'tshirt', 'polo', 'hoodie', 'jacket', 'blazer',
  'chinos', 'jeans', 'jogger', 'shorts', 'skirt', 'dress', 'jumpsuit', 'sweater', 'cardigan',
  'dupatta', 'sherwani', 'palazzo', 'leggings', 'coat', 'vest', 'frock', 'dungaree', 'nightsuit',
];
const COLORS = ['black', 'white', 'navy', 'maroon', 'olive', 'mustard', 'teal', 'beige', 'rust', 'lavender', 'charcoal', 'coral'];
const CATEGORIES = ['Women', 'Men', 'Kids'];
const SELLERS = ['Vastra', 'TrendKart', 'BazaarHub', 'StyleMart'];

function typo(rng, word) {
  if (word.length < 6) return word;
  const i = randomInt(rng, 1, word.length - 3);
  return word.slice(0, i) + word[i + 1] + word[i] + word.slice(i + 2);
}

function syntheticCatalog(size, seed) {
  const rng = mulberry32(seed);
  // Roughly 40 listings per brand, similar to a long-tail marketplace.
  const brands = Array.from({ length: Math.max(20, Math.floor(size / 40)) }, (_, i) => `Brand${i} ${pick(rng, ['Wear', 'Studio', 'Label', 'Co'])}`);
  const listings = [];
  const truth = new Map();
  let product = 0;
  while (listings.length < size) {
    product += 1;
    const brand = pick(rng, brands);
    const words = [pick(rng, ADJECTIVES), pick(rng, ADJECTIVES), pick(rng, TYPES)];
    const color = pick(rng, COLORS);
    const category = pick(rng, CATEGORIES);
    const basePrice = randomInt(rng, 299, 6999);
    const copies = Math.min(randomInt(rng, 1, 4), size - listings.length);
    for (let c = 0; c < copies; c += 1) {
      let title = words.map((w) => (rng() < 0.15 ? typo(rng, w) : w));
      if (rng() < 0.3) title = [title[2], title[0], title[1]];
      const id = `B${listings.length + 1}`;
      listings.push({
        listingId: id,
        seller: SELLERS[c % SELLERS.length],
        title: `${brand} ${title.join(' ')} - ${color}`,
        brand,
        category,
        price: Math.round(basePrice * (0.9 + rng() * 0.2)),
      });
      truth.set(id, { productId: `P${product}`, variantKey: color });
    }
  }
  return { listings, truth };
}

function parseSizes(argv) {
  const index = argv.indexOf('--sizes');
  const raw = index >= 0 ? argv[index + 1] : '1000,10000,50000';
  const sizes = String(raw).split(',').map(Number);
  if (sizes.some((n) => !Number.isInteger(n) || n < 10)) {
    throw new Error('--sizes must be a comma-separated list of integers >= 10');
  }
  return sizes;
}

async function main() {
  const rows = [];
  for (const size of parseSizes(process.argv.slice(2))) {
    const { listings, truth } = syntheticCatalog(size, 12345 + size);
    const start = performance.now();
    const result = await runPipeline({
      listings,
      groundTruth: truth,
      logger: null,
      config: { output: { retainNonMatchDetails: false } },
    });
    const totalMs = performance.now() - start;
    const e = result.evaluation;
    rows.push({
      listings: size,
      allPairs: e.blocking.allPairs,
      candidates: e.blocking.candidatePairs,
      reduction: `${(e.blocking.reductionRatio * 100).toFixed(3)}%`,
      completeness: `${(e.blocking.pairCompleteness * 100).toFixed(1)}%`,
      precision: `${(e.variant.precision * 100).toFixed(1)}%`,
      recall: `${(e.variant.recall * 100).toFixed(1)}%`,
      blockingMs: Math.round(result.summary.timingsMs.blocking),
      scoringMs: Math.round(result.summary.timingsMs.scoring),
      totalMs: Math.round(totalMs),
    });
    console.log(`Finished ${size} listings in ${Math.round(totalMs)} ms`);
  }
  console.table(rows);
}

main().catch((error) => {
  console.error(`Benchmark failed: ${error.message}`);
  process.exitCode = 1;
});
