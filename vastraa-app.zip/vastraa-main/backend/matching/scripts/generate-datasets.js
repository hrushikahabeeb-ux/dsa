'use strict';

/**
 * Builds the labelled multi-marketplace dataset used to run and evaluate
 * the matcher.
 *
 * Source of truth is Vastra's own catalog (frontend/public/mock-products.json
 * and its product photos). Two further marketplaces are derived from it the
 * way real third-party listings differ from a brand's catalog:
 *
 *   TrendKart   brand spelling variants, typos, reordered titles, synonyms,
 *               colour suffixes, style codes, some GTINs (a share of them
 *               with corrupted check digits), pack-of-2 variants, recompressed
 *               and cropped photos.
 *   BazaarHub   Hindi and Hinglish titles, different category labels, missing
 *               brand fields, colour variants with their own GTINs,
 *               duplicate listings by the same seller.
 *   StyleMart   look-alike products from other brands (hard negatives) that
 *               must not be merged with Vastra products.
 *
 * All randomness is seeded, so the dataset (and every metric computed on
 * it) is reproducible.
 *
 * Usage: node matching/scripts/generate-datasets.js [--seed 2026]
 */

const fs = require('fs');
const path = require('path');
const { Jimp } = require('jimp');

const { mulberry32, randomInt, pick } = require('../core/random');
const { makeGtin13 } = require('../rules/gtin');
const { HINDI_TO_ENGLISH } = require('../text/lexicon');

const ROOT = path.resolve(__dirname, '..', '..', '..');
const CATALOG_PATH = path.join(ROOT, 'frontend', 'public', 'mock-products.json');
const PUBLIC_DIR = path.join(ROOT, 'frontend', 'public');
const DATA_DIR = path.resolve(__dirname, '..', 'data');
const IMAGE_DIR = path.join(DATA_DIR, 'images');

const IMAGE_WIDTH = 320;
const IMAGE_QUALITY = 72;

const BRAND_PREFIX = {
  'Vastra Originals': 'VO',
  'Vastra Festive': 'VF',
  'Vastra Summer': 'VS',
  'Vastra Men': 'VM',
  'Vastra Western': 'VW',
  'Vastra Active': 'VA',
  'Vastra Kids': 'VK',
};

const ENGLISH_VARIANTS = {
  Kurti: 'Kurthi',
  'T-Shirt': 'Tee',
  Pants: 'Trousers',
  Saree: 'Sari',
  Lehenga: 'Lehnga',
  'Co-ord': 'Coord',
  Hoodie: 'Hoody',
  Chinos: 'Chino',
  Pyjama: 'Pajama',
  Embroidered: 'Embroidery',
};

const CATEGORY_LABELS_BAZAARHUB = { Women: 'Ladies', Men: 'Gents', Kids: 'Children' };
const AUDIENCE_WORD = { Women: "Women's", Men: "Men's", Kids: "Kids'" };

/** Look-alike listings from other brands. Each must stay unmatched. */
const HARD_NEGATIVES = [
  { lookalike: 'p1', brand: 'Rangmanch', title: 'Embroidered Rayon Kurti', color: 'Rust', category: 'Women', price: 999, imageOf: 'p30' },
  { lookalike: 'p9', brand: 'Urban Loom', title: 'Classic Pique Polo T-Shirt', color: 'Navy', category: 'Men', price: 649, imageOf: 'p25' },
  { lookalike: 'p10', brand: 'Kanchi Looms', title: 'Silk Blend Banarasi Saree', color: 'Deep Red', category: 'Women', price: 3299, imageOf: 'p20' },
  { lookalike: 'p4', brand: 'Urban Loom', title: 'Stretch Slim Fit Chinos', color: 'Desert Khaki', category: 'Men', price: 1149, imageOf: 'p23' },
  { lookalike: 'p28', brand: 'Kidsville', title: 'Kids Graphic Print T-Shirt', color: 'White', category: 'Kids', price: 349, imageOf: 'p16' },
  { lookalike: 'p17', brand: 'Streetory', title: 'Pastel Cropped Hoodie', color: 'Lavender', category: 'Women', price: 1049, imageOf: 'p22' },
  { lookalike: 'p14', brand: 'Tailorwise', title: 'Wool Blend Two Piece Formal Suit', color: 'Charcoal', category: 'Men', price: 5499, imageOf: 'p7' },
  { lookalike: 'p26', brand: 'Shaadi Couture', title: 'Silk Blend Sherwani Set', color: 'Ivory Gold', category: 'Men', price: 6999, imageOf: 'p24' },
];

const PACK_VARIANT_PRODUCTS = ['p9', 'p25', 'p28'];

function parseArgs(argv) {
  const args = { seed: 2026 };
  for (let i = 0; i < argv.length; i += 1) {
    if (argv[i] === '--seed') {
      const value = Number(argv[i + 1]);
      if (!Number.isInteger(value)) throw new Error('--seed must be an integer');
      args.seed = value;
      i += 1;
    }
  }
  return args;
}

function productNumber(product) {
  return Number(String(product.id).replace(/\D/g, ''));
}

function styleCodeFor(product) {
  const prefix = BRAND_PREFIX[product.brand] || 'VX';
  const line = product.subcategory.replace(/[^A-Za-z]/g, '').slice(0, 3).toUpperCase();
  return `${prefix}-${line}-${1000 + productNumber(product)}`;
}

/** GTIN-13 per product variant: India prefix 890, a fixed company code. */
function gtinFor(product, variantDigit) {
  const body = `8905566${String(productNumber(product)).padStart(3, '0')}${variantDigit}1`;
  return makeGtin13(body);
}

function corruptCheckDigit(gtin) {
  const last = Number(gtin[gtin.length - 1]);
  return gtin.slice(0, -1) + String((last + 3) % 10);
}

function roundPrice(value) {
  return Math.max(99, Math.round(value / 10) * 10 - 1);
}

function introduceTypo(rng, word) {
  if (word.length < 6) return word;
  const i = randomInt(rng, 1, word.length - 3);
  return word.slice(0, i) + word[i + 1] + word[i] + word.slice(i + 2);
}

function brandVariant(rng, brand) {
  const [first, ...rest] = brand.split(' ');
  const second = rest.join(' ');
  const options = [
    brand.toUpperCase(),
    brand.replace(' ', '-'),
    second.length >= 6 ? `${first} ${second.slice(0, 4)}${second.slice(5)}` : brand,
    brand,
  ];
  return pick(rng, options);
}

/** English to Hindi, taking the first Hindi spelling listed for each word. */
const ENGLISH_TO_HINDI = (() => {
  const map = new Map();
  for (const [hindi, english] of Object.entries(HINDI_TO_ENGLISH)) {
    if (english && !map.has(english)) map.set(english, hindi);
  }
  return map;
})();

function toHinglish(title) {
  let translated = 0;
  const words = title.split(' ').map((word) => {
    const hindi = ENGLISH_TO_HINDI.get(word.toLowerCase());
    if (hindi) {
      translated += 1;
      return hindi;
    }
    return word;
  });
  return { text: words.join(' '), translated };
}

function trendKartTitle(rng, product, color, brand) {
  let words = product.name.split(' ').map((w) => (rng() < 0.6 && ENGLISH_VARIANTS[w] ? ENGLISH_VARIANTS[w] : w));
  if (rng() < 0.4 && words.length > 2) words = [words[words.length - 1], ...words.slice(0, -1)];
  if (rng() < 0.35) {
    const candidates = words.map((w, i) => ({ w, i })).filter((x) => x.w.length >= 6);
    if (candidates.length) {
      const { i } = pick(rng, candidates);
      words[i] = introduceTypo(rng, words[i]);
    }
  }
  let title = `${brand} ${words.join(' ')}`;
  if (rng() < 0.5) title += ` for ${product.category}`;
  if (color) title += ` - ${color}`;
  return title;
}

function bazaarHubTitle(rng, product, color, { forceEnglish = false } = {}) {
  const hinglish = toHinglish(product.name);
  const useHindi = !forceEnglish && (hinglish.translated >= 2 || (hinglish.translated === 1 && rng() < 0.5));
  const colorText = useHindi && ENGLISH_TO_HINDI.has(color.toLowerCase())
    ? ENGLISH_TO_HINDI.get(color.toLowerCase())
    : color;
  if (useHindi) return { title: `${product.brand} ${hinglish.text} (${colorText})`, hindi: true };
  const name = product.name.split(' ').map((w) => (rng() < 0.4 && ENGLISH_VARIANTS[w] ? ENGLISH_VARIANTS[w] : w)).join(' ');
  return { title: `${product.brand} ${AUDIENCE_WORD[product.category]} ${name} (${color})`, hindi: false };
}

/**
 * Writes a transformed copy of a product photo, simulating how the same item
 * looks on another marketplace: different size, crop, exposure and, for
 * colour variants, a hue shift.
 */
async function writeImage(sourceRelative, targetRelative, rng, { hue = 0, strong = false } = {}) {
  const source = path.join(PUBLIC_DIR, sourceRelative.replace(/^\//, ''));
  if (!fs.existsSync(source)) return null;
  const image = await Jimp.read(source);
  image.resize({ w: IMAGE_WIDTH });
  const cropFraction = strong ? 0.05 : 0.03;
  const dx = Math.round(image.bitmap.width * cropFraction * rng());
  const dy = Math.round(image.bitmap.height * cropFraction * rng());
  image.crop({
    x: dx,
    y: dy,
    w: image.bitmap.width - 2 * dx,
    h: image.bitmap.height - 2 * dy,
  });
  if (strong) image.contrast((rng() - 0.5) * 0.2);
  image.brightness(0.9 + rng() * 0.2);
  if (hue) image.color([{ apply: 'hue', params: [hue] }]);
  const target = path.join(IMAGE_DIR, targetRelative);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  await image.write(target, { quality: IMAGE_QUALITY });
  return targetRelative;
}

async function generate({ seed }) {
  const catalog = JSON.parse(fs.readFileSync(CATALOG_PATH, 'utf8'));
  const products = catalog.products;
  if (!Array.isArray(products) || products.length === 0) {
    throw new Error(`No products found in ${CATALOG_PATH}`);
  }
  const byId = new Map(products.map((p) => [p.id, p]));
  const rng = mulberry32(seed);

  fs.rmSync(IMAGE_DIR, { recursive: true, force: true });
  fs.mkdirSync(IMAGE_DIR, { recursive: true });

  const listings = [];
  const truth = {};
  const add = (listing, productId, variantKey) => {
    listings.push(listing);
    truth[listing.listingId] = { productId, variantKey };
  };

  // Vastra: the brand's own catalog, one listing per product.
  for (const product of products) {
    const color = product.colorNames[0];
    const id = `VAS-${product.id}`;
    add({
      listingId: id,
      seller: 'Vastra',
      sellerSku: product.id,
      title: product.name,
      brand: product.brand,
      category: product.category,
      price: product.price,
      gtin: gtinFor(product, 0),
      styleCode: styleCodeFor(product),
      attributes: { color },
      image: await writeImage(product.images[0], `vastra/${id}.jpg`, rng),
    }, product.id, color.toLowerCase());
  }

  // TrendKart: every product, plus pack-of-2 variants of three basics.
  let tk = 0;
  for (const product of products) {
    tk += 1;
    const id = `TKT-${String(tk).padStart(4, '0')}`;
    const color = rng() < 0.85 ? product.colorNames[0] : null;
    const brand = brandVariant(rng, product.brand);
    let title = trendKartTitle(rng, product, color, brand);
    if (rng() < 0.4) title += ` | Style ${styleCodeFor(product)}`;
    let gtin = null;
    if (rng() < 0.55) gtin = rng() < 0.25 ? corruptCheckDigit(gtinFor(product, 0)) : gtinFor(product, 0);
    add({
      listingId: id,
      seller: 'TrendKart',
      sellerSku: `TK${randomInt(rng, 100000, 999999)}`,
      title,
      brand,
      category: product.category,
      price: roundPrice(product.price * (0.92 + rng() * 0.16)),
      gtin,
      image: await writeImage(product.images[0], `trendkart/${id}.jpg`, rng),
    }, product.id, product.colorNames[0].toLowerCase());
  }
  for (const productId of PACK_VARIANT_PRODUCTS) {
    const product = byId.get(productId);
    tk += 1;
    const id = `TKT-${String(tk).padStart(4, '0')}`;
    const color = product.colorNames[0];
    add({
      listingId: id,
      seller: 'TrendKart',
      sellerSku: `TK${randomInt(rng, 100000, 999999)}`,
      title: `${product.brand} ${product.name} Pack of 2 - ${color}`,
      brand: product.brand,
      category: product.category,
      price: roundPrice(product.price * 1.85),
      gtin: gtinFor(product, 9),
      image: await writeImage(product.images[0], `trendkart/${id}.jpg`, rng),
    }, product.id, `${color.toLowerCase()}|pack2`);
  }

  // BazaarHub: every product, colour variants of every fourth product, and
  // four duplicate listings by the same seller.
  let bz = 0;
  const nextBazaarId = () => {
    bz += 1;
    return `BZH-${String(bz).padStart(4, '0')}`;
  };
  for (let index = 0; index < products.length; index += 1) {
    const product = products[index];
    const color = product.colorNames[0];
    const id = nextBazaarId();
    const { title } = bazaarHubTitle(rng, product, color);
    add({
      listingId: id,
      seller: 'BazaarHub',
      sellerSku: `BH-${randomInt(rng, 10000, 99999)}`,
      title,
      brand: rng() < 0.3 ? '' : product.brand,
      category: CATEGORY_LABELS_BAZAARHUB[product.category],
      price: roundPrice(product.price * (0.9 + rng() * 0.2)),
      gtin: rng() < 0.2 ? gtinFor(product, 0) : null,
      image: await writeImage(product.images[0], `bazaarhub/${id}.jpg`, rng, { strong: true }),
    }, product.id, color.toLowerCase());

    if (index % 4 === 0) {
      const variantColor = product.colorNames[1];
      const variantId = nextBazaarId();
      const variant = bazaarHubTitle(rng, product, variantColor);
      add({
        listingId: variantId,
        seller: 'BazaarHub',
        sellerSku: `BH-${randomInt(rng, 10000, 99999)}`,
        title: rng() < 0.7 ? `${variant.title} ${styleCodeFor(product)}` : variant.title,
        brand: product.brand,
        category: CATEGORY_LABELS_BAZAARHUB[product.category],
        price: roundPrice(product.price * (0.9 + rng() * 0.2)),
        gtin: gtinFor(product, 1),
        image: await writeImage(product.images[0], `bazaarhub/${variantId}.jpg`, rng, { strong: true, hue: 60 }),
      }, product.id, variantColor.toLowerCase());
    }

    if (index % 8 === 3) {
      const duplicateId = nextBazaarId();
      const english = bazaarHubTitle(rng, product, color, { forceEnglish: true });
      const words = english.title.split(' ');
      const typoIndex = words.findIndex((w) => w.length >= 6);
      if (typoIndex >= 0) words[typoIndex] = introduceTypo(rng, words[typoIndex]);
      add({
        listingId: duplicateId,
        seller: 'BazaarHub',
        sellerSku: `BH-${randomInt(rng, 10000, 99999)}`,
        title: words.join(' '),
        brand: product.brand,
        category: CATEGORY_LABELS_BAZAARHUB[product.category],
        price: roundPrice(product.price * (0.9 + rng() * 0.2)),
        gtin: null,
        image: await writeImage(product.images[0], `bazaarhub/${duplicateId}.jpg`, rng, { strong: true }),
      }, product.id, color.toLowerCase());
    }
  }

  // StyleMart: look-alike products from other brands.
  let sm = 0;
  for (const negative of HARD_NEGATIVES) {
    sm += 1;
    const id = `STM-${String(sm).padStart(4, '0')}`;
    add({
      listingId: id,
      seller: 'StyleMart',
      sellerSku: `SM${randomInt(rng, 1000, 9999)}`,
      title: `${negative.brand} ${negative.title} - ${negative.color}`,
      brand: negative.brand,
      category: negative.category,
      price: negative.price,
      gtin: makeGtin13(`890777${String(sm).padStart(6, '0')}`),
      image: await writeImage(byId.get(negative.imageOf).images[0], `stylemart/${id}.jpg`, rng, { strong: true }),
    }, `other-${negative.brand.toLowerCase().replace(/\s+/g, '-')}-${sm}`, negative.color.toLowerCase());
  }

  const sellers = [...new Set(listings.map((l) => l.seller))];
  fs.writeFileSync(
    path.join(DATA_DIR, 'listings.json'),
    `${JSON.stringify({ seed, sellers, count: listings.length, listings }, null, 2)}\n`,
  );
  fs.writeFileSync(
    path.join(DATA_DIR, 'ground-truth.json'),
    `${JSON.stringify({ seed, labels: truth }, null, 2)}\n`,
  );
  return { listings: listings.length, sellers };
}

if (require.main === module) {
  generate(parseArgs(process.argv.slice(2)))
    .then(({ listings, sellers }) => {
      console.log(`Generated ${listings} listings across ${sellers.length} sellers (${sellers.join(', ')}).`);
    })
    .catch((error) => {
      console.error(`Dataset generation failed: ${error.message}`);
      process.exitCode = 1;
    });
}

module.exports = { generate, styleCodeFor, gtinFor };
