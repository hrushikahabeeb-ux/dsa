'use strict';

const fs = require('fs');
const path = require('path');

const { runPipeline } = require('./core/pipeline');
const { ReviewStore } = require('./core/reviewStore');
const { nearestNeighbours } = require('./similarity/embedding');
const { pairKey } = require('./blocking');
const { DECISIONS } = require('./core/scoring');

const DATA_DIR = path.join(__dirname, 'data');
const DEFAULT_PATHS = Object.freeze({
  listings: path.join(DATA_DIR, 'listings.json'),
  groundTruth: path.join(DATA_DIR, 'ground-truth.json'),
  decisions: path.join(DATA_DIR, 'review-decisions.json'),
  images: path.join(DATA_DIR, 'images'),
});

class MatchingServiceError extends Error {
  constructor(message, status = 500) {
    super(message);
    this.name = 'MatchingServiceError';
    this.status = status;
  }
}

function readJson(filePath, label) {
  if (!fs.existsSync(filePath)) {
    throw new MatchingServiceError(
      `${label} not found at ${filePath}. Run "npm run match:generate" in the backend folder.`,
      503,
    );
  }
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (error) {
    throw new MatchingServiceError(`${label} is not valid JSON: ${error.message}`, 500);
  }
}

/**
 * Owns the pipeline result for the API. Results are computed lazily and
 * cached; concurrent callers during a run share one in-flight promise, so a
 * burst of requests never starts duplicate runs.
 */
class MatchingService {
  constructor({ paths = DEFAULT_PATHS, config = {}, preferredSeller = 'Vastra', logger = console } = {}) {
    this.paths = { ...DEFAULT_PATHS, ...paths };
    this.config = config;
    this.preferredSeller = preferredSeller;
    this.logger = logger;
    this.reviewStore = new ReviewStore(this.paths.decisions);
    this._result = null;
    this._running = null;
  }

  async getResult({ refresh = false } = {}) {
    if (this._result && !refresh) return this._result;
    if (!this._running) {
      this._running = this._run().finally(() => {
        this._running = null;
      });
    }
    return this._running;
  }

  async _run() {
    const listingsFile = readJson(this.paths.listings, 'Listings dataset');
    const listings = Array.isArray(listingsFile) ? listingsFile : listingsFile.listings;
    if (!Array.isArray(listings)) {
      throw new MatchingServiceError('Listings dataset must contain a "listings" array', 500);
    }
    let groundTruth = new Map();
    if (fs.existsSync(this.paths.groundTruth)) {
      const labels = readJson(this.paths.groundTruth, 'Ground truth').labels || {};
      groundTruth = new Map(Object.entries(labels));
    }
    this._result = await runPipeline({
      listings,
      groundTruth,
      reviewStore: this.reviewStore,
      imageRoot: this.paths.images,
      config: this.config,
      preferredSeller: this.preferredSeller,
      logger: this.logger,
    });
    return this._result;
  }

  listingView(result, id) {
    const raw = result.rawListings.get(id);
    const record = result.recordById.get(id);
    if (!raw || !record) return null;
    return {
      listingId: id,
      seller: raw.seller,
      title: raw.title,
      brand: raw.brand || null,
      category: raw.category,
      price: raw.price,
      gtin: raw.gtin || null,
      gtinValid: record.gtin.valid,
      styleCode: record.styleCode,
      color: record.color,
      pack: record.pack,
      image: raw.image || null,
      unifiedId: result.clusters.unifiedIdOf.get(id) || null,
      familyId: result.clusters.familyIdOf.get(id) || null,
    };
  }

  linkView(result, link) {
    return {
      key: link.key,
      score: link.score,
      decision: link.decision,
      relation: link.relation,
      rule: link.rule,
      features: link.features,
      reasons: link.reasons,
      blockingSources: link.blockingSources,
      human: link.human || null,
      a: this.listingView(result, link.a),
      b: this.listingView(result, link.b),
    };
  }

  async summary() {
    const result = await this.getResult();
    return {
      generatedAt: result.generatedAt,
      ...result.summary,
      evaluation: result.evaluation
        ? {
          variant: result.evaluation.variant,
          family: result.evaluation.family,
          relationAccuracy: result.evaluation.relationAccuracy,
          blocking: result.evaluation.blocking,
        }
        : null,
    };
  }

  async evaluation() {
    const result = await this.getResult();
    if (!result.evaluation) throw new MatchingServiceError('No ground truth available for evaluation', 404);
    return result.evaluation;
  }

  /** Next items from the review heap, most uncertain first. */
  async reviewQueue(limit = 10) {
    const result = await this.getResult();
    const items = result.reviewQueue.topK(limit).map(({ link, uncertainty }) => ({
      ...this.linkView(result, link),
      uncertainty: Number(uncertainty.toFixed(4)),
    }));
    return { pending: result.reviewQueue.size, items };
  }

  async catalog({ offset = 0, limit = 50 } = {}) {
    const result = await this.getResult();
    const all = result.clusters.catalog;
    return { total: all.length, offset, limit, products: all.slice(offset, offset + limit) };
  }

  async links({ decision = null, relation = null, offset = 0, limit = 50 } = {}) {
    const result = await this.getResult();
    const filtered = result.links
      .filter((l) => (!decision || l.decision === decision) && (!relation || l.relation === relation))
      .sort((x, y) => y.score - x.score || (x.key < y.key ? -1 : 1));
    return {
      total: filtered.length,
      offset,
      limit,
      links: filtered.slice(offset, offset + limit).map((l) => this.linkView(result, l)),
    };
  }

  async listing(id) {
    const result = await this.getResult();
    const view = this.listingView(result, id);
    if (!view) throw new MatchingServiceError(`Listing ${id} not found`, 404);
    return view;
  }

  /** k most similar listings by embedding, via bounded-heap kNN search. */
  async similar(id, k = 5) {
    const result = await this.getResult();
    const record = result.recordById.get(id);
    if (!record) throw new MatchingServiceError(`Listing ${id} not found`, 404);
    const entries = result.records.map((r) => ({ id: r.listingId, vector: r.vector }));
    return nearestNeighbours(record.vector, entries, k, new Set([id])).map((hit) => ({
      similarity: Number(hit.similarity.toFixed(4)),
      listing: this.listingView(result, hit.id),
    }));
  }

  /**
   * Records a reviewer decision and recomputes clusters.
   * @param {string} key pair key "A::B"
   * @param {'accept'|'reject'} decision
   * @param {{ reviewer?: string }} [details]
   */
  async review(key, decision, { reviewer } = {}) {
    const result = await this.getResult();
    const [a, b] = String(key).split('::');
    const canonical = a && b ? pairKey(a, b) : null;
    const link = canonical ? result.linkByKey.get(canonical) : null;
    if (!link) throw new MatchingServiceError(`Pair ${key} is not a known candidate pair`, 404);
    if (decision !== 'accept' && decision !== 'reject') {
      throw new MatchingServiceError('decision must be "accept" or "reject"', 400);
    }
    const entry = this.reviewStore.set(canonical, decision, { reviewer, relation: link.relation });
    const refreshed = await this.getResult({ refresh: true });
    const updated = refreshed.linkByKey.get(canonical);
    return {
      decision: entry,
      link: this.linkView(refreshed, updated),
      reviewPending: refreshed.reviewQueue.size,
      autoMatched: refreshed.links.filter((l) => l.decision === DECISIONS.MATCH).length,
    };
  }

  async undoReview(key) {
    const [a, b] = String(key).split('::');
    const canonical = a && b ? pairKey(a, b) : null;
    if (!canonical || !this.reviewStore.remove(canonical)) {
      throw new MatchingServiceError(`No review decision stored for ${key}`, 404);
    }
    await this.getResult({ refresh: true });
    return { removed: canonical };
  }
}

module.exports = { MatchingService, MatchingServiceError, DEFAULT_PATHS };
