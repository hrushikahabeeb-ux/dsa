'use strict';

const { BinaryHeap } = require('../ds/heap');
const { fnv1a32 } = require('../core/hash');
const { mulberry32, gaussian } = require('../core/random');

/**
 * Dense vector representation of listing titles.
 *
 * Each title becomes a fixed-length vector built from word unigrams and
 * character trigrams, weighted by TF-IDF and folded into `dimensions`
 * buckets with the hashing trick (a signed hash avoids systematic bias from
 * collisions). Character trigrams make the vector robust to typos and
 * inflection ("kurthi" and "kurti" share most trigrams); IDF down-weights
 * features every listing has.
 *
 * This embedder has no external model dependency. The rest of the pipeline
 * only relies on the `embed(tokens) -> unit vector` contract, so a
 * pretrained multilingual sentence encoder can replace it without changes
 * elsewhere.
 */
class HashedTfIdfEmbedder {
  /**
   * @param {object} [options]
   * @param {number} [options.dimensions=512]
   */
  constructor({ dimensions = 512 } = {}) {
    if (!Number.isInteger(dimensions) || dimensions < 16) {
      throw new RangeError('dimensions must be an integer >= 16');
    }
    this.dimensions = dimensions;
    this._documentFrequency = new Map();
    this._documents = 0;
  }

  static features(tokens) {
    const features = [];
    for (const token of tokens) {
      features.push(`w:${token}`);
      const padded = `#${token}#`;
      for (let i = 0; i + 3 <= padded.length; i += 1) {
        features.push(`c:${padded.slice(i, i + 3)}`);
      }
    }
    return features;
  }

  /**
   * Learns document frequencies from the corpus.
   * @param {Array<string[]>} tokenLists
   */
  fit(tokenLists) {
    this._documentFrequency.clear();
    this._documents = tokenLists.length;
    for (const tokens of tokenLists) {
      for (const feature of new Set(HashedTfIdfEmbedder.features(tokens))) {
        this._documentFrequency.set(feature, (this._documentFrequency.get(feature) || 0) + 1);
      }
    }
    return this;
  }

  idf(feature) {
    const df = this._documentFrequency.get(feature) || 0;
    return Math.log((this._documents + 1) / (df + 1)) + 1;
  }

  /**
   * @param {string[]} tokens
   * @returns {Float32Array} L2-normalised vector (all zeros for empty input)
   */
  embed(tokens) {
    const counts = new Map();
    for (const feature of HashedTfIdfEmbedder.features(tokens)) {
      counts.set(feature, (counts.get(feature) || 0) + 1);
    }
    const vector = new Float32Array(this.dimensions);
    for (const [feature, count] of counts) {
      const hash = fnv1a32(feature);
      const bucket = hash % this.dimensions;
      const sign = (fnv1a32(feature, 0x5bd1e995) & 1) === 0 ? 1 : -1;
      vector[bucket] += sign * count * this.idf(feature);
    }
    return normalizeVector(vector);
  }
}

function normalizeVector(vector) {
  let norm = 0;
  for (let i = 0; i < vector.length; i += 1) norm += vector[i] * vector[i];
  norm = Math.sqrt(norm);
  if (norm > 0) {
    for (let i = 0; i < vector.length; i += 1) vector[i] /= norm;
  }
  return vector;
}

/**
 * Cosine similarity of two unit vectors, which reduces to their dot
 * product. Clamped to [0, 1] because a negative similarity carries no extra
 * information for matching.
 */
function cosine(a, b) {
  if (a.length !== b.length) throw new RangeError('vector dimensions differ');
  let dot = 0;
  for (let i = 0; i < a.length; i += 1) dot += a[i] * b[i];
  return Math.max(0, Math.min(1, dot));
}

/**
 * Exact k-nearest-neighbour search. A size-k min-heap on similarity keeps
 * the current best k; each new candidate is compared with the root (the
 * weakest retained neighbour). O(n log k) per query instead of the
 * O(n log n) of sorting all similarities.
 *
 * @param {Float32Array} query
 * @param {Array<{ id: string, vector: Float32Array }>} entries
 * @param {number} k
 * @param {Set<string>} [exclude] ids to skip (such as the query itself)
 * @returns {Array<{ id: string, similarity: number }>} best first
 */
function nearestNeighbours(query, entries, k, exclude = new Set()) {
  const heap = new BinaryHeap((a, b) => a.similarity - b.similarity);
  for (const entry of entries) {
    if (exclude.has(entry.id)) continue;
    heap.pushBounded({ id: entry.id, similarity: cosine(query, entry.vector) }, k);
  }
  return heap.drain().reverse();
}

/**
 * Random-hyperplane locality-sensitive hashing (SimHash) for cosine
 * similarity. Each bit records which side of a random hyperplane a vector
 * falls on; two vectors at angle theta agree on a bit with probability
 * 1 - theta / pi. Splitting the signature into bands and bucketing on each
 * band makes similar vectors collide in at least one band with high
 * probability, without comparing every pair.
 */
class RandomHyperplaneLSH {
  /**
   * @param {object} options
   * @param {number} options.dimensions
   * @param {number} [options.bits=64]
   * @param {number} [options.bands=8]
   * @param {number} [options.seed=42]
   */
  constructor({ dimensions, bits = 64, bands = 8, seed = 42 }) {
    if (bits % bands !== 0) throw new RangeError('bits must be divisible by bands');
    this.bits = bits;
    this.bands = bands;
    this.rowsPerBand = bits / bands;
    const rng = mulberry32(seed);
    this._planes = [];
    for (let b = 0; b < bits; b += 1) {
      const plane = new Float32Array(dimensions);
      for (let d = 0; d < dimensions; d += 1) plane[d] = gaussian(rng);
      this._planes.push(plane);
    }
  }

  /** @returns {string} signature as a string of '0'/'1' characters */
  signature(vector) {
    let out = '';
    for (const plane of this._planes) {
      let dot = 0;
      for (let d = 0; d < plane.length; d += 1) dot += plane[d] * vector[d];
      out += dot >= 0 ? '1' : '0';
    }
    return out;
  }

  /** Band keys: one bucket key per band, prefixed by the band number. */
  bandKeys(signature) {
    const keys = [];
    for (let b = 0; b < this.bands; b += 1) {
      keys.push(`${b}:${signature.slice(b * this.rowsPerBand, (b + 1) * this.rowsPerBand)}`);
    }
    return keys;
  }
}

module.exports = {
  HashedTfIdfEmbedder,
  RandomHyperplaneLSH,
  cosine,
  nearestNeighbours,
  normalizeVector,
};
