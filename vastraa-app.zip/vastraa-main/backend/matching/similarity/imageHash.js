'use strict';

const { Jimp } = require('jimp');

const SAMPLE_SIZE = 32;
const HASH_SIZE = 8;
const HASH_BITS = HASH_SIZE * HASH_SIZE;

/**
 * Precomputed DCT-II basis: COS_TABLE[u][x] = cos((2x + 1) u pi / 2N).
 * Building it once turns every hash into table lookups and multiplies.
 */
const COS_TABLE = (() => {
  const table = [];
  for (let u = 0; u < SAMPLE_SIZE; u += 1) {
    const row = new Float64Array(SAMPLE_SIZE);
    for (let x = 0; x < SAMPLE_SIZE; x += 1) {
      row[x] = Math.cos(((2 * x + 1) * u * Math.PI) / (2 * SAMPLE_SIZE));
    }
    table.push(row);
  }
  return table;
})();

/**
 * Low-frequency 2-D DCT of a square luminance matrix. The transform is
 * separable, so it runs as a 1-D DCT over rows and then over columns:
 * O(N^2 * K) for the K x K block we keep, instead of O(N^4) for a naive
 * 2-D sum.
 * @param {Float64Array[]} pixels N x N luminance
 * @param {number} keep size of the top-left block to compute
 */
function dctLowFrequencies(pixels, keep) {
  const n = pixels.length;
  const rowPass = [];
  for (let y = 0; y < n; y += 1) {
    const out = new Float64Array(keep);
    for (let u = 0; u < keep; u += 1) {
      let sum = 0;
      for (let x = 0; x < n; x += 1) sum += pixels[y][x] * COS_TABLE[u][x];
      out[u] = sum;
    }
    rowPass.push(out);
  }
  const result = [];
  for (let v = 0; v < keep; v += 1) {
    const out = new Float64Array(keep);
    for (let u = 0; u < keep; u += 1) {
      let sum = 0;
      for (let y = 0; y < n; y += 1) sum += rowPass[y][u] * COS_TABLE[v][y];
      out[u] = sum;
    }
    result.push(out);
  }
  return result;
}

/**
 * Perceptual hash (pHash) of an image file.
 *
 * The image is reduced to 32 x 32 greyscale, transformed with a DCT, and
 * the 8 x 8 lowest-frequency coefficients are kept. Each bit of the 64-bit
 * hash says whether a coefficient lies above the median. Low frequencies
 * describe overall structure, so the hash survives resizing, recompression,
 * brightness changes and small crops, while unrelated images differ in
 * roughly half their bits.
 *
 * @param {string} filePath
 * @returns {Promise<bigint>} 64-bit hash
 */
async function perceptualHash(filePath) {
  const image = await Jimp.read(filePath);
  image.resize({ w: SAMPLE_SIZE, h: SAMPLE_SIZE });
  image.greyscale();
  const { data, width } = image.bitmap;

  const pixels = [];
  for (let y = 0; y < SAMPLE_SIZE; y += 1) {
    const row = new Float64Array(SAMPLE_SIZE);
    for (let x = 0; x < SAMPLE_SIZE; x += 1) {
      row[x] = data[(y * width + x) * 4];
    }
    pixels.push(row);
  }

  const dct = dctLowFrequencies(pixels, HASH_SIZE);
  const coefficients = [];
  for (let v = 0; v < HASH_SIZE; v += 1) {
    for (let u = 0; u < HASH_SIZE; u += 1) coefficients.push(dct[v][u]);
  }
  // The DC term (0, 0) is average brightness; it is excluded from the
  // median so that a global brightness shift cannot flip many bits.
  const sorted = coefficients.slice(1).sort((a, b) => a - b);
  const median = (sorted[(sorted.length >> 1) - 1] + sorted[sorted.length >> 1]) / 2;

  let hash = 0n;
  for (const coefficient of coefficients) {
    hash = (hash << 1n) | (coefficient > median ? 1n : 0n);
  }
  return hash;
}

/**
 * Population count of a 32-bit integer using the parallel SWAR method:
 * sums adjacent bit pairs, then nibbles, then bytes, in constant time.
 */
function popcount32(value) {
  let v = value >>> 0;
  v -= (v >>> 1) & 0x55555555;
  v = (v & 0x33333333) + ((v >>> 2) & 0x33333333);
  v = (v + (v >>> 4)) & 0x0f0f0f0f;
  return Math.imul(v, 0x01010101) >>> 24;
}

/**
 * Hamming distance of two 64-bit hashes: popcount(a XOR b), computed on
 * the high and low 32-bit halves.
 */
function hammingDistance(a, b) {
  const x = BigInt.asUintN(64, a ^ b);
  const high = Number(x >> 32n);
  const low = Number(x & 0xffffffffn);
  return popcount32(high) + popcount32(low);
}

/** Similarity in [0, 1] derived from Hamming distance. */
function hashSimilarity(a, b) {
  return 1 - hammingDistance(a, b) / HASH_BITS;
}

function hashToHex(hash) {
  return BigInt.asUintN(64, hash).toString(16).padStart(16, '0');
}

module.exports = {
  perceptualHash,
  hammingDistance,
  hashSimilarity,
  popcount32,
  hashToHex,
  HASH_BITS,
};
