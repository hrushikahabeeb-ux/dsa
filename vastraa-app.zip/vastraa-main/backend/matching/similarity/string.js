'use strict';

/**
 * Levenshtein edit distance by dynamic programming.
 *
 * dp[i][j] is the minimum number of single-character insertions, deletions
 * and substitutions turning a[0..i) into b[0..j):
 *   dp[i][j] = min(dp[i-1][j] + 1, dp[i][j-1] + 1, dp[i-1][j-1] + cost)
 * Only the previous row is needed, so memory is O(min(m, n)) instead of
 * O(m * n). Time is O(m * n).
 *
 * If `maxDistance` is given, the computation stops as soon as every value
 * in a row exceeds it (no path can come back under the bound) and returns
 * maxDistance + 1. This early exit matters when most compared pairs are
 * clearly different.
 */
function levenshtein(a, b, maxDistance = Infinity) {
  if (a === b) return 0;
  let s = a;
  let t = b;
  if (s.length < t.length) {
    const tmp = s;
    s = t;
    t = tmp;
  }
  const m = s.length;
  const n = t.length;
  if (n === 0) return m;
  if (m - n > maxDistance) return maxDistance + 1;

  let previous = new Array(n + 1);
  let current = new Array(n + 1);
  for (let j = 0; j <= n; j += 1) previous[j] = j;

  for (let i = 1; i <= m; i += 1) {
    current[0] = i;
    let rowMin = current[0];
    const si = s.charCodeAt(i - 1);
    for (let j = 1; j <= n; j += 1) {
      const cost = si === t.charCodeAt(j - 1) ? 0 : 1;
      const value = Math.min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + cost);
      current[j] = value;
      if (value < rowMin) rowMin = value;
    }
    if (rowMin > maxDistance) return maxDistance + 1;
    const swap = previous;
    previous = current;
    current = swap;
  }
  return previous[n];
}

/**
 * Damerau-Levenshtein distance, optimal string alignment variant.
 *
 * Adds one operation to Levenshtein: transposing two adjacent characters
 * costs 1 instead of 2. Swapped letters are the most common typing error
 * ("fsetive" for "festive"), so this is the right distance for deciding
 * whether two tokens are the same word. Needs three rows of the DP table,
 * O(m * n) time and O(n) memory, with the same early exit as levenshtein.
 */
function damerauLevenshtein(a, b, maxDistance = Infinity) {
  if (a === b) return 0;
  const m = a.length;
  const n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;
  if (Math.abs(m - n) > maxDistance) return maxDistance + 1;

  let beforePrevious = new Array(n + 1).fill(0);
  let previous = new Array(n + 1);
  let current = new Array(n + 1);
  for (let j = 0; j <= n; j += 1) previous[j] = j;

  for (let i = 1; i <= m; i += 1) {
    current[0] = i;
    let rowMin = i;
    for (let j = 1; j <= n; j += 1) {
      const cost = a.charCodeAt(i - 1) === b.charCodeAt(j - 1) ? 0 : 1;
      let value = Math.min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + cost);
      if (
        i > 1 && j > 1
        && a.charCodeAt(i - 1) === b.charCodeAt(j - 2)
        && a.charCodeAt(i - 2) === b.charCodeAt(j - 1)
      ) {
        value = Math.min(value, beforePrevious[j - 2] + 1);
      }
      current[j] = value;
      if (value < rowMin) rowMin = value;
    }
    if (rowMin > maxDistance) return maxDistance + 1;
    const recycled = beforePrevious;
    beforePrevious = previous;
    previous = current;
    current = recycled;
  }
  return previous[n];
}

/**
 * Typo tolerance for whole tokens. Short tokens must match exactly because
 * a single edit there usually changes the word ("kurta" and "kurti" are
 * different garments); longer tokens may differ by one edit, very long ones
 * by two.
 */
function allowedTokenEdits(length) {
  if (length >= 9) return 2;
  if (length >= 6) return 1;
  return 0;
}

function tokensEquivalent(a, b) {
  if (a === b) return true;
  const allowed = allowedTokenEdits(Math.min(a.length, b.length));
  if (allowed === 0) return false;
  return damerauLevenshtein(a, b, allowed) <= allowed;
}

/**
 * Jaccard similarity with typo-tolerant token equality.
 *
 * Exact matches are counted first through a hash-set lookup. Each remaining
 * token then claims at most one unmatched token of the other side that is
 * within its allowed edit distance, so a token is never matched twice.
 */
function softJaccard(setA, setB) {
  if (setA.size === 0 && setB.size === 0) return 1;
  const [small, large] = setA.size <= setB.size ? [setA, setB] : [setB, setA];
  let matches = 0;
  const unmatchedSmall = [];
  const claimed = new Set();
  for (const token of small) {
    if (large.has(token)) {
      matches += 1;
      claimed.add(token);
    } else {
      unmatchedSmall.push(token);
    }
  }
  const unmatchedLarge = [...large].filter((token) => !claimed.has(token));
  for (const token of unmatchedSmall) {
    const index = unmatchedLarge.findIndex((candidate) => tokensEquivalent(token, candidate));
    if (index !== -1) {
      matches += 1;
      unmatchedLarge.splice(index, 1);
    }
  }
  const union = setA.size + setB.size - matches;
  return union === 0 ? 0 : matches / union;
}

/** Levenshtein distance scaled to a similarity in [0, 1]. */
function levenshteinRatio(a, b) {
  const longest = Math.max(a.length, b.length);
  if (longest === 0) return 1;
  return 1 - levenshtein(a, b) / longest;
}

/**
 * Jaccard similarity |A ∩ B| / |A ∪ B| of two sets. Iterates the smaller set
 * and probes the larger, O(min(|A|, |B|)) with hash-set lookups.
 */
function jaccard(setA, setB) {
  if (setA.size === 0 && setB.size === 0) return 1;
  const [small, large] = setA.size <= setB.size ? [setA, setB] : [setB, setA];
  let intersection = 0;
  for (const item of small) {
    if (large.has(item)) intersection += 1;
  }
  const union = setA.size + setB.size - intersection;
  return union === 0 ? 0 : intersection / union;
}

/**
 * Jaro-Winkler similarity, tuned for short strings such as brand names.
 * Jaro counts characters that match within a sliding window and the
 * transpositions among them; Winkler adds a bonus for a shared prefix of up
 * to four characters, since typos rarely occur at the start of a name.
 */
function jaroWinkler(a, b, prefixScale = 0.1) {
  if (a === b) return 1;
  if (a.length === 0 || b.length === 0) return 0;

  const window = Math.max(0, Math.floor(Math.max(a.length, b.length) / 2) - 1);
  const aMatched = new Array(a.length).fill(false);
  const bMatched = new Array(b.length).fill(false);
  let matches = 0;

  for (let i = 0; i < a.length; i += 1) {
    const start = Math.max(0, i - window);
    const end = Math.min(b.length - 1, i + window);
    for (let j = start; j <= end; j += 1) {
      if (!bMatched[j] && a[i] === b[j]) {
        aMatched[i] = true;
        bMatched[j] = true;
        matches += 1;
        break;
      }
    }
  }
  if (matches === 0) return 0;

  let transpositions = 0;
  let k = 0;
  for (let i = 0; i < a.length; i += 1) {
    if (!aMatched[i]) continue;
    while (!bMatched[k]) k += 1;
    if (a[i] !== b[k]) transpositions += 1;
    k += 1;
  }
  transpositions /= 2;

  const jaro = (matches / a.length + matches / b.length + (matches - transpositions) / matches) / 3;

  let prefix = 0;
  const maxPrefix = Math.min(4, a.length, b.length);
  while (prefix < maxPrefix && a[prefix] === b[prefix]) prefix += 1;

  return jaro + prefix * prefixScale * (1 - jaro);
}

/**
 * Relative price closeness in [0, 1]: 1 for equal prices, falling linearly
 * to 0 when one price is `tolerance` (default 50%) away from the other.
 * Returns null when either price is unknown so the scorer can skip it.
 */
function priceProximity(a, b, tolerance = 0.5) {
  if (!(a > 0) || !(b > 0)) return null;
  const relativeGap = Math.abs(a - b) / Math.max(a, b);
  return Math.max(0, 1 - relativeGap / tolerance);
}

module.exports = {
  levenshtein,
  levenshteinRatio,
  damerauLevenshtein,
  tokensEquivalent,
  allowedTokenEdits,
  softJaccard,
  jaccard,
  jaroWinkler,
  priceProximity,
};
