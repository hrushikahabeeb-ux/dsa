'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { BinaryHeap } = require('../ds/heap');
const { UnionFind } = require('../ds/unionFind');
const { Trie } = require('../ds/trie');
const { BKTree } = require('../ds/bkTree');

test('BinaryHeap pops in priority order and heapifies in bulk', () => {
  const values = [9, 4, 7, 1, 8, 2, 6, 3, 5, 0];
  const heap = BinaryHeap.from(values, (a, b) => a - b);
  assert.deepEqual(heap.drain(), [...values].sort((a, b) => a - b));

  const pushed = new BinaryHeap((a, b) => b - a);
  values.forEach((v) => pushed.push(v));
  assert.equal(pushed.peek(), 9);
  assert.deepEqual(pushed.topK(3), [9, 8, 7]);
  assert.equal(pushed.size, values.length, 'topK must not consume the heap');
});

test('BinaryHeap.pushBounded keeps the k largest items', () => {
  const heap = new BinaryHeap((a, b) => a - b);
  [5, 1, 9, 3, 7, 8].forEach((v) => heap.pushBounded(v, 3));
  assert.deepEqual(heap.drain(), [7, 8, 9]);
});

test('UnionFind merges, finds and groups components', () => {
  const uf = new UnionFind();
  ['a', 'b', 'c', 'd', 'e'].forEach((id) => uf.makeSet(id));
  uf.union('a', 'b');
  uf.union('c', 'd');
  uf.union('b', 'd');
  assert.ok(uf.connected('a', 'c'));
  assert.ok(!uf.connected('a', 'e'));
  assert.equal(uf.sizeOf('d'), 4);
  const groups = [...uf.components().values()].map((g) => g.sort()).sort();
  assert.deepEqual(groups, [['a', 'b', 'c', 'd'], ['e']]);
  assert.equal(uf.union('a', 'd').reason, 'already-connected');
});

test('UnionFind guard vetoes merges with conflicting metadata', () => {
  const uf = new UnionFind({
    guard: (x, y) => (x.color && y.color && x.color !== y.color ? 'colour conflict' : null),
    mergeMeta: (x, y) => ({ color: x.color || y.color }),
  });
  uf.makeSet('red', { color: 'red' });
  uf.makeSet('unknown', { color: null });
  uf.makeSet('blue', { color: 'blue' });
  assert.equal(uf.union('red', 'unknown').merged, true);
  const veto = uf.union('unknown', 'blue');
  assert.equal(veto.merged, false);
  assert.equal(veto.reason, 'colour conflict');
  assert.ok(!uf.connected('red', 'blue'), 'transitive false merge must be blocked');
});

test('UnionFind rejects unknown ids', () => {
  const uf = new UnionFind();
  assert.throws(() => uf.find('missing'), /unknown id/);
});

test('Trie longest-prefix match prefers the longest key', () => {
  const trie = new Trie();
  trie.insert('कढ़ाई', 'embroidered').insert('कढ़ाईदार', 'embroidered-adj');
  assert.equal(trie.size, 2);
  assert.deepEqual(trie.longestPrefixMatch('कढ़ाईदार कुर्ती', 0).value, 'embroidered-adj');
  assert.equal(trie.longestPrefixMatch('xyz', 0), null);
  assert.ok(trie.has('कढ़ाई'));
  assert.equal(trie.get('कढ़ा'), undefined);
});

test('BKTree range search matches a linear scan', () => {
  const distance = (a, b) => Math.abs(a - b);
  const tree = new BKTree(distance);
  const values = Array.from({ length: 200 }, (_, i) => (i * 37) % 211);
  values.forEach((v) => tree.add(v, v));
  const found = tree.search(100, 5).map((r) => r.item).sort((a, b) => a - b);
  const expected = values.filter((v) => Math.abs(v - 100) <= 5).sort((a, b) => a - b);
  assert.deepEqual(found, expected);
  assert.ok(tree.lastQueryVisits < values.length, 'search should prune subtrees');
});
