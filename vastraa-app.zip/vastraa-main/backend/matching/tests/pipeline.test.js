'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const { runPipeline, ingest } = require('../core/pipeline');
const { ReviewStore } = require('../core/reviewStore');
const { precisionRecall } = require('../core/evaluation');
const { resolveConfig } = require('../config');

const DATA = path.join(__dirname, '..', 'data');
const listings = JSON.parse(fs.readFileSync(path.join(DATA, 'listings.json'), 'utf8')).listings;
const groundTruth = new Map(Object.entries(
  JSON.parse(fs.readFileSync(path.join(DATA, 'ground-truth.json'), 'utf8')).labels,
));

test('ingestion rejects malformed listings without failing the run', () => {
  const { accepted, rejected } = ingest([
    { listingId: 'a', title: 'x' },
    { listingId: 'a', title: 'duplicate' },
    { title: 'no id' },
    { listingId: 'b', title: '  ' },
    { listingId: 'c::d', title: 'bad id' },
  ]);
  assert.equal(accepted.length, 1);
  assert.deepEqual(rejected.map((r) => r.reason), [
    'duplicate listingId', 'missing listingId', 'missing title', 'listingId must not contain "::"',
  ]);
});

test('config rejects unknown keys and inverted thresholds', () => {
  assert.throws(() => resolveConfig({ wieghts: {} }), /Unknown matching config key/);
  assert.throws(() => resolveConfig({ thresholds: { review: 0.9, autoMatch: 0.8 } }), /must not exceed/);
});

test('precisionRecall handles empty sets', () => {
  assert.deepEqual(
    precisionRecall(new Set(), new Set()),
    { precision: 1, recall: 1, f1: 1, truePositives: 0, falsePositives: 0, falseNegatives: 0 },
  );
});

test('end-to-end pipeline meets quality targets on the labelled dataset', async () => {
  const result = await runPipeline({
    listings,
    groundTruth,
    imageRoot: path.join(DATA, 'images'),
    preferredSeller: 'Vastra',
    logger: null,
  });
  const e = result.evaluation;
  assert.equal(e.blocking.pairCompleteness, 1, 'blocking must not lose true pairs');
  assert.ok(e.blocking.reductionRatio > 0.7);
  assert.ok(e.variant.precision >= 0.98, `variant precision ${e.variant.precision}`);
  assert.ok(e.variant.recall >= 0.9, `variant recall ${e.variant.recall}`);
  assert.ok(e.family.precision >= 0.98, `family precision ${e.family.precision}`);

  for (const negative of listings.filter((l) => l.seller === 'StyleMart')) {
    const family = result.clusters.familyIdOf.get(negative.listingId);
    const members = result.clusters.familyClusters.find((c) => c.includes(negative.listingId));
    assert.deepEqual(members, [negative.listingId], `${negative.listingId} must stay unmatched (${family})`);
  }
});

test('human decisions override the model and persist', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vastra-review-'));
  const store = new ReviewStore(path.join(dir, 'decisions.json'));
  const run = () => runPipeline({ listings, groundTruth, reviewStore: store, logger: null });

  const before = await run();
  const pending = before.reviewQueue.topK(1)[0];
  assert.ok(pending, 'dataset should produce at least one review item');

  store.set(pending.link.key, 'reject', { reviewer: 'test' });
  const afterReject = await run();
  assert.equal(afterReject.linkByKey.get(pending.link.key).decision, 'non-match');
  assert.equal(afterReject.reviewQueue.size, before.reviewQueue.size - 1);

  const reloaded = new ReviewStore(path.join(dir, 'decisions.json'));
  assert.equal(reloaded.get(pending.link.key).decision, 'reject');
  assert.throws(() => reloaded.set(pending.link.key, 'maybe'), /Decision must be/);
  fs.rmSync(dir, { recursive: true, force: true });
});
