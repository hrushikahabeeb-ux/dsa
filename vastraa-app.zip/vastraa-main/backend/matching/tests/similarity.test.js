'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');

const {
  levenshtein,
  levenshteinRatio,
  damerauLevenshtein,
  tokensEquivalent,
  softJaccard,
  jaccard,
  jaroWinkler,
  priceProximity,
} = require('../similarity/string');
const {
  HashedTfIdfEmbedder,
  RandomHyperplaneLSH,
  cosine,
  nearestNeighbours,
} = require('../similarity/embedding');
const { popcount32, hammingDistance, perceptualHash } = require('../similarity/imageHash');

test('Levenshtein distance matches known values and honours the bound', () => {
  assert.equal(levenshtein('kitten', 'sitting'), 3);
  assert.equal(levenshtein('', 'abc'), 3);
  assert.equal(levenshtein('same', 'same'), 0);
  assert.equal(levenshtein('abcdef', 'uvwxyz', 2), 3, 'early exit returns maxDistance + 1');
  assert.equal(levenshteinRatio('abcd', 'abcf'), 0.75);
});

test('Damerau-Levenshtein counts an adjacent swap as one edit', () => {
  assert.equal(levenshtein('fsetive', 'festive'), 2);
  assert.equal(damerauLevenshtein('fsetive', 'festive'), 1);
  assert.ok(tokensEquivalent('fsetive', 'festive'));
  assert.ok(!tokensEquivalent('kurta', 'kurti'), 'short words must match exactly');
});

test('Jaccard and soft Jaccard', () => {
  const a = new Set(['kids', 'festive', 'kurta', 'set']);
  const b = new Set(['kids', 'fsetive', 'kurta', 'set']);
  assert.equal(jaccard(a, b), 3 / 5);
  assert.equal(softJaccard(a, b), 1);
  assert.equal(softJaccard(new Set(), new Set()), 1);
});

test('Jaro-Winkler rewards shared prefixes', () => {
  assert.ok(Math.abs(jaroWinkler('martha', 'marhta') - 0.9611) < 1e-3);
  assert.ok(jaroWinkler('vastra festive', 'vastra festve') > 0.95);
  assert.ok(jaroWinkler('urban loom', 'vastra men') < 0.6);
});

test('priceProximity is linear and skips missing prices', () => {
  assert.equal(priceProximity(100, 100), 1);
  assert.equal(priceProximity(100, 50), 0);
  assert.equal(priceProximity(null, 50), null);
});

test('embeddings are unit length and robust to typos', () => {
  const docs = [['festive', 'kurta', 'set'], ['fsetive', 'kurta', 'set'], ['denim', 'jacket']];
  const embedder = new HashedTfIdfEmbedder({ dimensions: 256 }).fit(docs);
  const [x, y, z] = docs.map((d) => embedder.embed(d));
  const norm = Math.sqrt(x.reduce((s, v) => s + v * v, 0));
  assert.ok(Math.abs(norm - 1) < 1e-6);
  assert.ok(cosine(x, y) > 0.6);
  assert.ok(cosine(x, z) < 0.2);
  const hits = nearestNeighbours(x, [{ id: 'y', vector: y }, { id: 'z', vector: z }], 1);
  assert.equal(hits[0].id, 'y');
});

test('random-hyperplane LSH gives similar vectors similar signatures', () => {
  const embedder = new HashedTfIdfEmbedder({ dimensions: 128 }).fit([['a'], ['b']]);
  const lsh = new RandomHyperplaneLSH({ dimensions: 128, bits: 32, bands: 4, seed: 1 });
  const v = embedder.embed(['printed', 'palazzo', 'pants']);
  assert.equal(lsh.signature(v), lsh.signature(v));
  assert.equal(lsh.bandKeys(lsh.signature(v)).length, 4);
});

test('popcount and Hamming distance', () => {
  assert.equal(popcount32(0), 0);
  assert.equal(popcount32(0xffffffff), 32);
  assert.equal(popcount32(0b1011), 3);
  assert.equal(hammingDistance(0n, (1n << 64n) - 1n), 64);
  assert.equal(hammingDistance(0b1010n, 0b0110n), 2);
});

test('perceptual hash tolerates re-encoding but separates different photos', async () => {
  const images = path.join(__dirname, '..', 'data', 'images');
  const original = await perceptualHash(path.join(images, 'vastra', 'VAS-p1.jpg'));
  const resold = await perceptualHash(path.join(images, 'trendkart', 'TKT-0001.jpg'));
  const unrelated = await perceptualHash(path.join(images, 'vastra', 'VAS-p14.jpg'));
  assert.ok(hammingDistance(original, resold) <= 10);
  assert.ok(hammingDistance(original, unrelated) > 16);
});
