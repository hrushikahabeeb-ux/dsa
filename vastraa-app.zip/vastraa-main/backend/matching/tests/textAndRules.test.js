'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { normalizeText, normalizeBrand, normalizeCategory } = require('../text/normalize');
const { transliterateWord } = require('../text/transliterate');
const { ColorIndex, extractFeatures, normalizeStyleCode } = require('../text/attributes');
const { parseGtin, computeCheckDigit, makeGtin13 } = require('../rules/gtin');

test('normalizeText joins hyphens, maps synonyms and drops stopwords', () => {
  const { tokens } = normalizeText("Men's Classic T-Shirts for the Gym");
  assert.deepEqual(tokens, ['men', 'classic', 'tshirt', 'gym']);
});

test('normalizeText translates Hindi through the dictionary trie', () => {
  const result = normalizeText('Vastra कढ़ाईदार Mirror कुर्ती (लाल)');
  assert.deepEqual(result.tokens, ['vastra', 'embroidered', 'mirror', 'kurti', 'red']);
  assert.equal(result.multilingual.translated, 3);
});

test('transliteration applies inherent vowels and schwa deletion', () => {
  assert.equal(transliterateWord('कमल'), 'kamal');
  assert.equal(transliterateWord('राम'), 'raam');
  assert.equal(transliterateWord('पड़ोस'), 'paros');
});

test('brand and category normalisation converge on spelling variants', () => {
  assert.equal(normalizeBrand('VASTRA-ORIGINALS'), 'vastra originals');
  assert.equal(normalizeBrand('by Vastra Originals'), 'vastra originals');
  assert.equal(normalizeCategory('Ladies'), 'women');
  assert.equal(normalizeCategory('Gents'), 'men');
  assert.equal(normalizeCategory('Children'), 'kids');
});

test('GTIN check digits validate UPC and EAN forms', () => {
  assert.equal(computeCheckDigit('03600029145'), 2);
  const upc = parseGtin('036000291452');
  const ean = parseGtin('0036000291452');
  assert.equal(upc.valid, true);
  assert.equal(upc.gtin14, ean.gtin14, 'UPC-A and its EAN-13 form are the same GTIN');
  assert.equal(parseGtin('036000291453').reason, 'bad-check-digit');
  assert.equal(parseGtin('12345').reason, 'invalid-length-5');
  assert.equal(parseGtin('').present, false);
  assert.equal(parseGtin(makeGtin13('890556600101')).valid, true);
});

test('style codes are recognised only in the brand-line-model shape', () => {
  assert.equal(normalizeStyleCode('Kurti | Style vo-kur-1001'), 'VO-KUR-1001');
  assert.equal(normalizeStyleCode('Kids Set 2024'), null);
});

test('extractFeatures separates colour, pack and brand from the core title', () => {
  const colorIndex = new ColorIndex(['Red Bandhani']);
  const features = extractFeatures({
    listingId: 'x1',
    seller: 'S',
    title: 'Vasrta Festive Bandhani Lehenga Choli Set Pack of 2 - Red Bandhani',
    brand: 'Vastra Festive',
    category: 'Ladies',
    price: 4299,
  }, { colorIndex, knownBrands: ['vastra festive'] });
  assert.equal(features.color, 'red bandhani');
  assert.equal(features.pack, 2);
  assert.equal(features.category, 'women');
  assert.deepEqual(features.coreTokens, ['bandhani', 'lehenga', 'choli', 'set']);
});

test('extractFeatures infers a missing brand from the title', () => {
  const features = extractFeatures({
    listingId: 'x2', seller: 'S', title: 'Vastra Kids Graphic Tee', brand: '', category: 'Kids',
  }, { colorIndex: new ColorIndex(), knownBrands: ['vastra kids', 'vastra'] });
  assert.equal(features.brand, 'vastra kids');
});
