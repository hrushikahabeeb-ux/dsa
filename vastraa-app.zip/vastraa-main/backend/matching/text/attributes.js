'use strict';

const { normalizeText, normalizeBrand, normalizeCategory } = require('./normalize');
const { AUDIENCE_TOKENS, BASE_COLORS } = require('./lexicon');
const { parseGtin } = require('../rules/gtin');
const { tokensEquivalent } = require('../similarity/string');

/**
 * Brand-model pattern for seller style codes such as "VO-KRT-1001":
 * a 2-3 letter brand prefix, a 3 letter product-line code and a 4 digit
 * model number. The same model shared across colours identifies a product
 * family; its presence on two listings is strong evidence either way.
 */
const STYLE_CODE_PATTERN = /\b([A-Za-z]{2,3})-([A-Za-z]{3})-(\d{4})\b/;
const STYLE_CODE_GLOBAL = new RegExp(STYLE_CODE_PATTERN.source, 'g');

const SIZE_PATTERN = /\bsize (xxs|xs|s|m|l|xl|xxl|xxxl|\d{1,2})\b/;
const PACK_PATTERN = /\bpack (?:of )?(\d{1,2})\b/;
const MAX_COLOR_PHRASE_TOKENS = 3;

function normalizeStyleCode(raw) {
  if (!raw) return null;
  const match = STYLE_CODE_PATTERN.exec(String(raw));
  if (!match) return null;
  return `${match[1]}-${match[2]}-${match[3]}`.toUpperCase();
}

/**
 * Colour vocabulary indexed by phrase length so that multi-word colours
 * ("bottle green") win over their single-word parts ("green").
 */
class ColorIndex {
  constructor(phrases = []) {
    this._phrases = new Set();
    for (const phrase of [...BASE_COLORS, ...phrases]) this.add(phrase);
  }

  add(phrase) {
    const normalized = normalizeText(phrase).tokens.join(' ');
    if (normalized) this._phrases.add(normalized);
  }

  has(phrase) {
    return this._phrases.has(phrase);
  }

  get size() {
    return this._phrases.size;
  }

  /**
   * Finds the colour phrase in a token list, scanning right to left because
   * sellers conventionally append the colour at the end of a title.
   * @returns {{ color: string, start: number, length: number } | null}
   */
  find(tokens) {
    for (let end = tokens.length; end > 0; end -= 1) {
      for (let len = Math.min(MAX_COLOR_PHRASE_TOKENS, end); len >= 1; len -= 1) {
        const phrase = tokens.slice(end - len, end).join(' ');
        if (this._phrases.has(phrase)) return { color: phrase, start: end - len, length: len };
      }
    }
    return null;
  }
}

/**
 * Last occurrence of a token sequence inside a token list.
 * @returns {{ start: number, length: number } | null}
 */
function findPhrase(tokens, phrase) {
  if (phrase.length === 0 || phrase.length > tokens.length) return null;
  for (let start = tokens.length - phrase.length; start >= 0; start -= 1) {
    let matches = true;
    for (let k = 0; k < phrase.length; k += 1) {
      if (tokens[start + k] !== phrase[k]) {
        matches = false;
        break;
      }
    }
    if (matches) return { start, length: phrase.length };
  }
  return null;
}

/**
 * Finds a known brand inside a title when the brand field is empty.
 * @param {string[]} titleTokens
 * @param {string[]} knownBrands normalised brand strings
 */
function inferBrandFromTitle(titleTokens, knownBrands) {
  const text = ` ${titleTokens.join(' ')} `;
  let best = '';
  for (const brand of knownBrands) {
    if (brand.length > best.length && text.includes(` ${brand} `)) best = brand;
  }
  return best;
}

/**
 * Converts one raw listing into the feature record used by every later
 * stage. Pure function: the listing is not mutated.
 *
 * @param {object} listing raw catalog listing
 * @param {object} context
 * @param {ColorIndex} context.colorIndex
 * @param {string[]} context.knownBrands
 */
function extractFeatures(listing, { colorIndex, knownBrands }) {
  const rawTitle = String(listing.title || '');

  const styleCode = normalizeStyleCode(listing.styleCode) || normalizeStyleCode(rawTitle);
  const titleWithoutCodes = rawTitle.replace(STYLE_CODE_GLOBAL, ' ');

  const title = normalizeText(titleWithoutCodes);
  let brand = normalizeBrand(listing.brand);
  if (!brand) brand = inferBrandFromTitle(title.tokens, knownBrands);

  const structuredColor = listing.attributes && listing.attributes.color
    ? normalizeText(listing.attributes.color).tokens.join(' ')
    : null;
  const titleColor = colorIndex.find(title.tokens);
  const color = structuredColor || (titleColor ? titleColor.color : null);

  const phraseText = title.allTokens.join(' ');
  const sizeMatch = SIZE_PATTERN.exec(phraseText);
  const packMatch = PACK_PATTERN.exec(phraseText);
  const size = (listing.attributes && listing.attributes.size)
    ? String(listing.attributes.size).toLowerCase()
    : (sizeMatch ? sizeMatch[1] : null);
  const pack = packMatch ? Number(packMatch[1]) : 1;

  // Core tokens describe the product itself: no brand, audience, colour,
  // size or pack words, since those are compared by dedicated features.
  const excluded = new Set([...brand.split(' '), ...AUDIENCE_TOKENS, 'size', 'pack']);
  // Remove only the contiguous colour phrase, never scattered words: in
  // "Bandhani Lehenga Choli Set" with colour "Red Bandhani" the product word
  // "bandhani" must survive.
  const colorTokenPositions = new Set();
  const colorSpan = structuredColor
    ? findPhrase(title.tokens, structuredColor.split(' '))
    : titleColor;
  if (colorSpan) {
    for (let k = 0; k < colorSpan.length; k += 1) colorTokenPositions.add(colorSpan.start + k);
  }
  if (sizeMatch) excluded.add(sizeMatch[1]);
  if (packMatch) excluded.add(packMatch[1]);

  // Brand words are removed even when misspelt in the title ("Vasrta").
  const brandTokens = brand.split(' ').filter(Boolean);
  const isBrandToken = (token) => brandTokens.some((b) => tokensEquivalent(token, b));

  const coreTokens = title.tokens.filter((token, index) => (
    !excluded.has(token)
    && !isBrandToken(token)
    && !colorTokenPositions.has(index)
  ));

  return {
    listingId: listing.listingId,
    seller: listing.seller,
    rawTitle,
    brand,
    category: normalizeCategory(listing.category),
    titleTokens: title.tokens,
    coreTokens,
    coreTokenSet: new Set(coreTokens),
    coreSorted: [...coreTokens].sort().join(' '),
    color,
    size,
    pack,
    styleCode,
    gtin: parseGtin(listing.gtin),
    price: Number.isFinite(Number(listing.price)) ? Number(listing.price) : null,
    image: listing.image || null,
    multilingual: title.multilingual,
  };
}

module.exports = {
  ColorIndex,
  extractFeatures,
  normalizeStyleCode,
  inferBrandFromTitle,
  findPhrase,
};
