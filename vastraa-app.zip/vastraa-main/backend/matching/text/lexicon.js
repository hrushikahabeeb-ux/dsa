'use strict';

/**
 * Static vocabularies used by normalisation and attribute extraction.
 *
 * These are data, not logic: extending the matcher to a new language or a
 * new product domain means extending these tables, not changing algorithms.
 */

/**
 * Hindi (Devanagari) to English dictionary for apparel listings. Keys are
 * normalised to NFC when loaded into the trie, so either composed or
 * decomposed nukta forms in the input resolve to the same entry.
 */
const HINDI_TO_ENGLISH = Object.freeze({
  'कुर्ती': 'kurti',
  'कुर्तियाँ': 'kurti',
  'कुर्ता': 'kurta',
  'कुर्ते': 'kurta',
  'साड़ी': 'saree',
  'साड़ियाँ': 'saree',
  'लहंगा': 'lehenga',
  'लहँगा': 'lehenga',
  'चोली': 'choli',
  'दुपट्टा': 'dupatta',
  'शेरवानी': 'sherwani',
  'सलवार': 'salwar',
  'पटियाला': 'patiala',
  'सूट': 'suit',
  'जैकेट': 'jacket',
  'बंदगला': 'bandhgala',
  'कढ़ाईदार': 'embroidered',
  'कढ़ाई': 'embroidered',
  'रेशमी': 'silk',
  'रेशम': 'silk',
  'सिल्क': 'silk',
  'सूती': 'cotton',
  'कॉटन': 'cotton',
  'ज़री': 'zari',
  'जरी': 'zari',
  'बांधनी': 'bandhani',
  'बंधेज': 'bandhani',
  'फुलकारी': 'phulkari',
  'अनारकली': 'anarkali',
  'फ्रॉक': 'frock',
  'पजामा': 'pyjama',
  'पायजामा': 'pyjama',
  'सेट': 'set',
  'पार्टी': 'party',
  'त्योहारी': 'festive',
  'उत्सव': 'festive',
  'बच्चों': 'kids',
  'बच्चे': 'kids',
  'लड़कियों': 'girls',
  'लड़कों': 'boys',
  'महिलाओं': 'women',
  'महिला': 'women',
  'पुरुषों': 'men',
  'पुरुष': 'men',
  'लाल': 'red',
  'हरा': 'green',
  'हरी': 'green',
  'नीला': 'blue',
  'नीली': 'blue',
  'काला': 'black',
  'काली': 'black',
  'सफ़ेद': 'white',
  'सफेद': 'white',
  'पीला': 'yellow',
  'गुलाबी': 'pink',
  'मरून': 'maroon',
  'बैंगनी': 'purple',
  // Function words: mapped to an empty string so they are dropped.
  'के': '',
  'की': '',
  'का': '',
  'लिए': '',
  'और': '',
  'वाली': '',
  'वाला': '',
});

/**
 * Token-level synonym and spelling-variant map. Applied after lowercasing
 * and hyphen joining, so "T-Shirt" arrives here as "tshirt".
 */
const SYNONYMS = Object.freeze({
  tee: 'tshirt',
  tees: 'tshirt',
  tshirts: 'tshirt',
  sari: 'saree',
  saris: 'saree',
  sarees: 'saree',
  kurthi: 'kurti',
  kurtis: 'kurti',
  kurtas: 'kurta',
  lehnga: 'lehenga',
  lehanga: 'lehenga',
  lehengas: 'lehenga',
  pajama: 'pyjama',
  pajamas: 'pyjama',
  pyjamas: 'pyjama',
  trouser: 'pants',
  trousers: 'pants',
  pant: 'pants',
  joggers: 'jogger',
  hoody: 'hoodie',
  hoodies: 'hoodie',
  frocks: 'frock',
  jackets: 'jacket',
  blazers: 'blazer',
  shirts: 'shirt',
  chino: 'chinos',
  dresses: 'dress',
  skirts: 'skirt',
  suits: 'suit',
  sets: 'set',
  coords: 'coord',
  dungarees: 'dungaree',
  cardigans: 'cardigan',
  dupattas: 'dupatta',
  embroidery: 'embroidered',
  embroided: 'embroidered',
  ladies: 'women',
  womens: 'women',
  woman: 'women',
  female: 'women',
  gents: 'men',
  mens: 'men',
  man: 'men',
  male: 'men',
  kid: 'kids',
  children: 'kids',
  childrens: 'kids',
  child: 'kids',
  girl: 'girls',
  boy: 'boys',
  grey: 'gray',
});

/** Tokens that carry no identifying information in a product title. */
const STOPWORDS = Object.freeze(new Set([
  'a', 'an', 'the', 'by', 'for', 'with', 'and', 'of', 'in', 'on', 'to',
  'new', 'latest', 'genuine', 'authentic', 'best', 'sale', 'offer', 'free',
  'shipping', 'combo', 'deal', 'hot', 'trending', 'stylish', 'fashion',
  'wear', 'style', 'online', 'buy',
]));

/** Canonical top-level categories and the labels sellers use for them. */
const CATEGORY_ALIASES = Object.freeze({
  women: 'women',
  womens: 'women',
  woman: 'women',
  ladies: 'women',
  female: 'women',
  men: 'men',
  mens: 'men',
  man: 'men',
  gents: 'men',
  male: 'men',
  kids: 'kids',
  kid: 'kids',
  children: 'kids',
  childrens: 'kids',
  boys: 'kids',
  girls: 'kids',
  infant: 'kids',
});

/** Tokens describing audience rather than product; excluded from title cores. */
const AUDIENCE_TOKENS = Object.freeze(new Set(['women', 'men', 'kids', 'girls', 'boys', 'unisex']));

/**
 * Base colour vocabulary. The pipeline extends it at run time with every
 * structured colour value found in the ingested catalogs.
 */
const BASE_COLORS = Object.freeze([
  'black', 'white', 'red', 'green', 'blue', 'yellow', 'pink', 'purple',
  'orange', 'brown', 'gray', 'maroon', 'navy', 'beige', 'cream', 'ivory',
  'olive', 'khaki', 'teal', 'mint', 'peach', 'coral', 'lavender', 'mauve',
  'rust', 'tan', 'charcoal', 'burgundy', 'indigo', 'lilac', 'plum', 'gold',
  'silver', 'saffron', 'emerald', 'magenta', 'fuchsia', 'crimson', 'amethyst',
  'camel', 'sand', 'mocha', 'caramel', 'graphite', 'sage', 'rose',
  'chocolate', 'wine', 'mustard', 'turquoise', 'aqua', 'lemon', 'lime',
  'copper', 'bronze', 'champagne', 'pearl', 'onion', 'mehendi', 'rani',
  'peacock', 'coffee', 'grape', 'berry', 'blush', 'nude', 'stone', 'denim blue',
  'navy blue', 'sky blue', 'royal blue', 'baby blue', 'bottle green',
  'deep red', 'off white', 'light blue', 'dark blue', 'dark green', 'light pink',
]);

module.exports = {
  HINDI_TO_ENGLISH,
  SYNONYMS,
  STOPWORDS,
  CATEGORY_ALIASES,
  AUDIENCE_TOKENS,
  BASE_COLORS,
};
