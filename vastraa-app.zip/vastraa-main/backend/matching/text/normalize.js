'use strict';

const { Trie } = require('../ds/trie');
const { transliterateWord, isDevanagari } = require('./transliterate');
const {
  HINDI_TO_ENGLISH,
  SYNONYMS,
  STOPWORDS,
  CATEGORY_ALIASES,
} = require('./lexicon');

/**
 * Dictionary trie, built once at module load. Keys are NFKC-normalised so
 * that composed and decomposed forms of nukta characters in the input
 * match the same entry.
 */
const HINDI_TRIE = (() => {
  const trie = new Trie();
  for (const [hindi, english] of Object.entries(HINDI_TO_ENGLISH)) {
    trie.insert(hindi.normalize('NFKC'), english);
  }
  return trie;
})();

/**
 * Replaces every Devanagari run with English words (dictionary, via
 * longest-prefix trie matching) or a phonetic transliteration (fallback).
 * @param {string} text NFKC-normalised text
 * @returns {{ text: string, translated: number, transliterated: number }}
 */
function translateDevanagari(text) {
  let out = '';
  let translated = 0;
  let transliterated = 0;
  let unknown = '';

  const flushUnknown = () => {
    if (unknown.length > 0) {
      out += ` ${transliterateWord(unknown)} `;
      transliterated += 1;
      unknown = '';
    }
  };

  let i = 0;
  while (i < text.length) {
    const ch = String.fromCodePoint(text.codePointAt(i));
    if (!isDevanagari(ch)) {
      flushUnknown();
      out += ch;
      i += ch.length;
      continue;
    }
    const match = HINDI_TRIE.longestPrefixMatch(text, i);
    if (match) {
      flushUnknown();
      out += ` ${match.value} `;
      translated += 1;
      i += match.length;
    } else {
      unknown += ch;
      i += ch.length;
    }
  }
  flushUnknown();
  return { text: out, translated, transliterated };
}

/**
 * Canonical text normalisation shared by every comparison in the pipeline.
 *
 * Steps: Unicode NFKC, Hindi translation or transliteration, Latin
 * diacritic stripping, lowercasing, joining intra-word hyphens and
 * apostrophes ("T-Shirt" -> "tshirt", "Kid's" -> "kids"), punctuation
 * removal, splitting glued letters and digits ("size32" -> "size 32"),
 * synonym mapping and stopword removal.
 *
 * @param {string} raw
 * @returns {{
 *   tokens: string[],        tokens with stopwords removed
 *   allTokens: string[],     tokens including stopwords (for phrase regexes)
 *   text: string,            tokens joined by single spaces
 *   multilingual: { translated: number, transliterated: number }
 * }}
 */
function normalizeText(raw) {
  let s = String(raw == null ? '' : raw).normalize('NFKC');

  const translation = translateDevanagari(s);
  s = translation.text;

  s = s.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  s = s.toLowerCase();
  s = s.replace(/&/g, ' and ').replace(/\+/g, ' ');
  s = s.replace(/([a-z0-9])['\u2019`-]+(?=[a-z0-9])/g, '$1');
  s = s.replace(/[^a-z0-9]+/g, ' ');
  s = s.replace(/([a-z])(\d)/g, '$1 $2').replace(/(\d)([a-z])/g, '$1 $2');

  const allTokens = [];
  for (const piece of s.split(' ')) {
    if (!piece) continue;
    const mapped = Object.prototype.hasOwnProperty.call(SYNONYMS, piece) ? SYNONYMS[piece] : piece;
    if (mapped) allTokens.push(mapped);
  }
  const tokens = allTokens.filter((t) => !STOPWORDS.has(t));

  return {
    tokens,
    allTokens,
    text: tokens.join(' '),
    multilingual: {
      translated: translation.translated,
      transliterated: translation.transliterated,
    },
  };
}

/**
 * Brand normalisation keeps word boundaries but drops noise words, so
 * "VASTRA ORIGINALS", "Vastra-Originals" and "by Vastra Originals" converge.
 * Hyphens between words are treated as spaces here, unlike in titles.
 */
function normalizeBrand(raw) {
  const spaced = String(raw == null ? '' : raw).replace(/[-_/]+/g, ' ');
  return normalizeText(spaced).tokens.join(' ');
}

/**
 * Maps a seller's category label onto the canonical category set.
 * Unknown labels are returned normalised rather than discarded.
 */
function normalizeCategory(raw) {
  const tokens = normalizeText(raw).allTokens;
  for (const token of tokens) {
    if (Object.prototype.hasOwnProperty.call(CATEGORY_ALIASES, token)) {
      return CATEGORY_ALIASES[token];
    }
  }
  return tokens.join(' ');
}

module.exports = {
  normalizeText,
  normalizeBrand,
  normalizeCategory,
  translateDevanagari,
};
