'use strict';

/**
 * Phonetic Devanagari to Latin transliteration.
 *
 * This is the fallback used when a Devanagari word is not in the translation
 * dictionary. It turns unseen words into a stable Latin spelling (for
 * example a brand name written in Hindi) so that fuzzy matching can still
 * compare them with English listings.
 *
 * Rules implemented:
 *   - consonants carry an inherent "a" unless followed by a vowel sign
 *     (matra) or a virama;
 *   - nukta forms (ड़, ढ़, ज़, फ़, क़, ख़, ग़) map to their Urdu or Persian sounds;
 *   - anusvara and chandrabindu become "n";
 *   - the word-final inherent "a" is deleted (schwa deletion), which is
 *     how Hindi is actually pronounced ("kamal", not "kamala").
 */

const CONSONANTS = new Map([
  ['क', 'k'], ['ख', 'kh'], ['ग', 'g'], ['घ', 'gh'], ['ङ', 'n'],
  ['च', 'ch'], ['छ', 'chh'], ['ज', 'j'], ['झ', 'jh'], ['ञ', 'n'],
  ['ट', 't'], ['ठ', 'th'], ['ड', 'd'], ['ढ', 'dh'], ['ण', 'n'],
  ['त', 't'], ['थ', 'th'], ['द', 'd'], ['ध', 'dh'], ['न', 'n'],
  ['प', 'p'], ['फ', 'ph'], ['ब', 'b'], ['भ', 'bh'], ['म', 'm'],
  ['य', 'y'], ['र', 'r'], ['ल', 'l'], ['व', 'v'], ['श', 'sh'],
  ['ष', 'sh'], ['स', 's'], ['ह', 'h'],
]);

const NUKTA_FORMS = new Map([
  ['ड', 'r'], ['ढ', 'rh'], ['ज', 'z'], ['फ', 'f'],
  ['क', 'q'], ['ख', 'kh'], ['ग', 'gh'],
]);

const INDEPENDENT_VOWELS = new Map([
  ['अ', 'a'], ['आ', 'aa'], ['इ', 'i'], ['ई', 'ee'], ['उ', 'u'],
  ['ऊ', 'oo'], ['ऋ', 'ri'], ['ए', 'e'], ['ऐ', 'ai'], ['ओ', 'o'],
  ['औ', 'au'], ['ऑ', 'o'],
]);

const VOWEL_SIGNS = new Map([
  ['ा', 'aa'], ['ि', 'i'], ['ी', 'ee'], ['ु', 'u'], ['ू', 'oo'],
  ['ृ', 'ri'], ['े', 'e'], ['ै', 'ai'], ['ो', 'o'], ['ौ', 'au'],
  ['ॉ', 'o'],
]);

const VIRAMA = '\u094D';
const NUKTA = '\u093C';
const NASALS = new Set(['\u0902', '\u0901']); // anusvara, chandrabindu
const VISARGA = '\u0903';

const DEVANAGARI_DIGITS = '०१२३४५६७८९';

/** True when the character is in the Devanagari Unicode block. */
function isDevanagari(ch) {
  const cp = ch.codePointAt(0);
  return cp >= 0x0900 && cp <= 0x097f;
}

/**
 * Transliterates one Devanagari word (no spaces). Characters outside the
 * block are copied through unchanged.
 * @param {string} word NFC-normalised input
 * @returns {string}
 */
function transliterateWord(word) {
  const chars = Array.from(word);
  let out = '';
  let endsWithInherentA = false;

  for (let i = 0; i < chars.length; i += 1) {
    const ch = chars[i];
    endsWithInherentA = false;

    if (CONSONANTS.has(ch)) {
      let latin = CONSONANTS.get(ch);
      let next = chars[i + 1];
      if (next === NUKTA) {
        latin = NUKTA_FORMS.get(ch) || latin;
        i += 1;
        next = chars[i + 1];
      }
      if (next === VIRAMA) {
        out += latin;
        i += 1;
      } else if (VOWEL_SIGNS.has(next)) {
        out += latin + VOWEL_SIGNS.get(next);
        i += 1;
      } else {
        out += `${latin}a`;
        endsWithInherentA = true;
      }
      continue;
    }

    if (INDEPENDENT_VOWELS.has(ch)) {
      out += INDEPENDENT_VOWELS.get(ch);
    } else if (NASALS.has(ch)) {
      out += 'n';
    } else if (ch === VISARGA) {
      out += 'h';
    } else if (DEVANAGARI_DIGITS.includes(ch)) {
      out += String(DEVANAGARI_DIGITS.indexOf(ch));
    } else if (ch === NUKTA || ch === VIRAMA || VOWEL_SIGNS.has(ch)) {
      // Orphan combining mark: nothing sensible to emit.
    } else {
      out += ch;
    }
  }

  // Schwa deletion: drop the final inherent vowel of multi-syllable words.
  if (endsWithInherentA && out.length > 2) out = out.slice(0, -1);
  return out;
}

module.exports = { transliterateWord, isDevanagari };
