const path = require('path');
const express = require('express');

const authMiddleware = require('../middleware/auth');
const { MatchingService, MatchingServiceError, DEFAULT_PATHS } = require('../matching/service');

const router = express.Router();
const service = new MatchingService();

const LISTING_ID_PATTERN = /^[A-Za-z0-9_-]{1,64}$/;
const PAIR_KEY_PATTERN = /^[A-Za-z0-9_-]{1,64}::[A-Za-z0-9_-]{1,64}$/;
const VALID_DECISIONS = new Set(['match', 'review', 'non-match']);
const VALID_RELATIONS = new Set(['same', 'variant']);

/** Parses a bounded integer query parameter, falling back to a default. */
function intParam(value, fallback, { min, max }) {
  if (value === undefined || value === '') return fallback;
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < min || parsed > max) {
    throw new MatchingServiceError(`Expected an integer between ${min} and ${max}, received "${value}"`, 400);
  }
  return parsed;
}

function listingIdParam(value) {
  if (!LISTING_ID_PATTERN.test(String(value))) {
    throw new MatchingServiceError('Invalid listing id', 400);
  }
  return String(value);
}

function pairKeyParam(value) {
  if (!PAIR_KEY_PATTERN.test(String(value || ''))) {
    throw new MatchingServiceError('Invalid pair key; expected "LISTING_A::LISTING_B"', 400);
  }
  return String(value);
}

/** Wraps an async handler so rejections reach the error middleware. */
const handle = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res)).then((body) => {
    if (!res.headersSent) res.json({ success: true, ...body });
  }).catch(next);
};

// Product photos used by the matcher (read-only static files).
router.use('/images', express.static(path.resolve(DEFAULT_PATHS.images), {
  fallthrough: false,
  index: false,
  dotfiles: 'deny',
  maxAge: '1h',
}));

// GET /api/matching/summary
router.get('/summary', handle(async () => ({ summary: await service.summary() })));

// GET /api/matching/evaluation
router.get('/evaluation', handle(async () => ({ evaluation: await service.evaluation() })));

// GET /api/matching/review?limit=10
router.get('/review', handle(async (req) => {
  const limit = intParam(req.query.limit, 10, { min: 1, max: 100 });
  return service.reviewQueue(limit);
}));

// POST /api/matching/review  { key, decision: 'accept' | 'reject' }
router.post('/review', authMiddleware, handle(async (req) => {
  const key = pairKeyParam(req.body && req.body.key);
  const decision = req.body && req.body.decision;
  if (decision !== 'accept' && decision !== 'reject') {
    throw new MatchingServiceError('decision must be "accept" or "reject"', 400);
  }
  return service.review(key, decision, { reviewer: req.userId || 'unknown' });
}));

// POST /api/matching/review/undo  { key }
router.post('/review/undo', authMiddleware, handle(async (req) => {
  const key = pairKeyParam(req.body && req.body.key);
  return service.undoReview(key);
}));

// GET /api/matching/catalog?offset=0&limit=50
router.get('/catalog', handle(async (req) => service.catalog({
  offset: intParam(req.query.offset, 0, { min: 0, max: 1e7 }),
  limit: intParam(req.query.limit, 50, { min: 1, max: 200 }),
})));

// GET /api/matching/links?decision=match&relation=variant&offset=0&limit=50
router.get('/links', handle(async (req) => {
  const { decision, relation } = req.query;
  if (decision && !VALID_DECISIONS.has(decision)) {
    throw new MatchingServiceError(`decision must be one of ${[...VALID_DECISIONS].join(', ')}`, 400);
  }
  if (relation && !VALID_RELATIONS.has(relation)) {
    throw new MatchingServiceError(`relation must be one of ${[...VALID_RELATIONS].join(', ')}`, 400);
  }
  return service.links({
    decision: decision || null,
    relation: relation || null,
    offset: intParam(req.query.offset, 0, { min: 0, max: 1e7 }),
    limit: intParam(req.query.limit, 50, { min: 1, max: 200 }),
  });
}));

// GET /api/matching/listings/:id
router.get('/listings/:id', handle(async (req) => ({
  listing: await service.listing(listingIdParam(req.params.id)),
})));

// GET /api/matching/listings/:id/similar?k=5
router.get('/listings/:id/similar', handle(async (req) => ({
  similar: await service.similar(
    listingIdParam(req.params.id),
    intParam(req.query.k, 5, { min: 1, max: 50 }),
  ),
})));

// POST /api/matching/run  (recompute from the dataset files)
router.post('/run', authMiddleware, handle(async () => {
  await service.getResult({ refresh: true });
  return { summary: await service.summary() };
}));

// Errors from this router are reported with their own status codes.
router.use((err, _req, res, next) => {
  if (err instanceof MatchingServiceError) {
    return res.status(err.status).json({ success: false, message: err.message });
  }
  if (err && err.status === 404 && err.expose) {
    return res.status(404).json({ success: false, message: 'Image not found' });
  }
  return next(err);
});

module.exports = router;
