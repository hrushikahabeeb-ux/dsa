import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BackNav, EmptyState, Spinner } from '../components/shared';
import { useUIStore } from '../store';
import { matchingAPI, matchingImageUrl } from '../utils/matchingApi';

const TABS = [
  { id: 'review', label: 'Review' },
  { id: 'catalog', label: 'Unified catalog' },
  { id: 'quality', label: 'Quality' },
];

const FEATURE_LABELS = [
  ['title', 'Title'],
  ['embedding', 'Meaning'],
  ['image', 'Photo'],
  ['price', 'Price'],
  ['brand', 'Brand'],
];

const percent = (value) => (value === null || value === undefined ? 'n/a' : `${(value * 100).toFixed(1)}%`);
const rupees = (value) => (typeof value === 'number' ? `₹${value.toLocaleString('en-IN')}` : '—');

function ScoreBar({ value, color = 'var(--teal-dark)' }) {
  const width = Math.max(0, Math.min(1, value ?? 0)) * 100;
  return (
    <div style={{ height: 6, background: 'var(--border2)', borderRadius: 'var(--r-full)', overflow: 'hidden' }}>
      <div style={{ width: `${width}%`, height: '100%', background: color, borderRadius: 'var(--r-full)' }} />
    </div>
  );
}

function ListingColumn({ listing }) {
  const [imageFailed, setImageFailed] = useState(false);
  const src = matchingImageUrl(listing.image);
  return (
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ aspectRatio: '4 / 5', borderRadius: 'var(--r-sm)', overflow: 'hidden', background: 'var(--teal-xxlight)', marginBottom: 8 }}>
        {src && !imageFailed ? (
          <img src={src} alt={listing.title} loading="lazy" onError={() => setImageFailed(true)}
            style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        ) : (
          <div className="flex-center" style={{ height: '100%', color: 'var(--muted2)', fontSize: 12 }}>No photo</div>
        )}
      </div>
      <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--teal-darker)', marginBottom: 2 }}>{listing.seller}</div>
      <div style={{ fontSize: 13, fontWeight: 600, lineHeight: 1.35, marginBottom: 6, overflowWrap: 'anywhere' }}>{listing.title}</div>
      <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 4 }}>{rupees(listing.price)}</div>
      <div style={{ fontSize: 11, color: 'var(--muted)', lineHeight: 1.6 }}>
        <div>Colour: {listing.color || 'not stated'}{listing.pack > 1 ? `, pack of ${listing.pack}` : ''}</div>
        <div>
          GTIN: {listing.gtin ? (
            <span style={{ color: listing.gtinValid ? 'var(--text2)' : 'var(--danger)' }}>
              {listing.gtin}{listing.gtinValid ? '' : ' (invalid)'}
            </span>
          ) : 'none'}
        </div>
        {listing.styleCode && <div>Style code: {listing.styleCode}</div>}
      </div>
    </div>
  );
}

function ReviewCard({ item, busy, onDecide }) {
  const isVariant = item.relation === 'variant';
  return (
    <div className="surface-card" style={{ padding: 14, marginBottom: 14, border: '1px solid var(--border2)', borderRadius: 'var(--r)', background: 'var(--surface)' }}>
      <div className="flex-between" style={{ marginBottom: 10 }}>
        <span className={`badge ${isVariant ? 'badge-purple' : 'badge-info'}`}>
          {isVariant ? 'Proposed: variant of' : 'Proposed: same item'}
        </span>
        <span style={{ fontSize: 13, fontWeight: 700 }}>Score {item.score.toFixed(2)}</span>
      </div>

      <div style={{ display: 'flex', gap: 12, marginBottom: 12 }}>
        <ListingColumn listing={item.a} />
        <ListingColumn listing={item.b} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '64px 1fr 44px', gap: '6px 8px', alignItems: 'center', marginBottom: 12 }}>
        {FEATURE_LABELS.map(([key, label]) => (
          <FeatureRow key={key} label={label} value={item.features?.[key]} />
        ))}
      </div>

      {item.reasons?.length > 0 && (
        <ul style={{ margin: '0 0 12px 16px', fontSize: 12, color: 'var(--text2)', lineHeight: 1.6 }}>
          {item.reasons.map((reason) => <li key={reason}>{reason}</li>)}
        </ul>
      )}

      <div style={{ display: 'flex', gap: 10 }}>
        <button type="button" className="btn btn-outline btn-sm" style={{ flex: 1 }} disabled={busy}
          onClick={() => onDecide(item, 'reject')}>
          Not a match
        </button>
        <button type="button" className="btn btn-primary btn-sm" style={{ flex: 1 }} disabled={busy}
          onClick={() => onDecide(item, 'accept')}>
          {isVariant ? 'Link as variant' : 'Merge as same item'}
        </button>
      </div>
    </div>
  );
}

function FeatureRow({ label, value }) {
  return (
    <>
      <span style={{ fontSize: 12, color: 'var(--muted)' }}>{label}</span>
      <ScoreBar value={value} />
      <span style={{ fontSize: 12, textAlign: 'right' }}>{value === null || value === undefined ? '—' : value.toFixed(2)}</span>
    </>
  );
}

function ReviewTab({ onChanged }) {
  const { showToast } = useUIStore();
  const [state, setState] = useState({ loading: true, error: null, items: [], pending: 0 });
  const [busyKey, setBusyKey] = useState(null);
  const [lastDecision, setLastDecision] = useState(null);

  const load = useCallback(async () => {
    setState((s) => ({ ...s, loading: true, error: null }));
    try {
      const res = await matchingAPI.reviewQueue(20);
      setState({ loading: false, error: null, items: res.items, pending: res.pending });
    } catch (err) {
      setState({ loading: false, error: err.message, items: [], pending: 0 });
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const decide = async (item, decision) => {
    setBusyKey(item.key);
    try {
      await matchingAPI.decide(item.key, decision);
      setLastDecision({ key: item.key, decision });
      showToast(decision === 'accept' ? 'Match confirmed' : 'Marked as not a match');
      await load();
      onChanged();
    } catch (err) {
      showToast(err.status === 401 ? 'Sign in to record review decisions' : err.message, 'error');
    } finally {
      setBusyKey(null);
    }
  };

  const undo = async () => {
    if (!lastDecision) return;
    try {
      await matchingAPI.undo(lastDecision.key);
      setLastDecision(null);
      showToast('Decision undone');
      await load();
      onChanged();
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  if (state.loading && state.items.length === 0) {
    return <div className="flex-center" style={{ paddingTop: 60 }}><Spinner size={32} /></div>;
  }
  if (state.error) {
    return (
      <EmptyState icon="⚠" title="Could not load the review queue" subtitle={state.error}
        action={<button type="button" className="btn btn-primary" onClick={load}>Try again</button>} />
    );
  }
  return (
    <>
      <div className="flex-between" style={{ marginBottom: 12 }}>
        <span style={{ fontSize: 13, color: 'var(--muted)' }}>
          {state.pending} pair{state.pending === 1 ? '' : 's'} waiting, least certain first
        </span>
        {lastDecision && (
          <button type="button" className="btn btn-ghost btn-sm" onClick={undo}>Undo last</button>
        )}
      </div>
      {state.items.length === 0 ? (
        <EmptyState icon="✓" title="Nothing left to review"
          subtitle="Every candidate pair has been matched automatically or decided by a reviewer." />
      ) : (
        state.items.map((item) => (
          <ReviewCard key={item.key} item={item} busy={busyKey !== null} onDecide={decide} />
        ))
      )}
    </>
  );
}

function CatalogTab({ version }) {
  const [state, setState] = useState({ loading: true, error: null, products: [], total: 0 });

  useEffect(() => {
    let cancelled = false;
    setState((s) => ({ ...s, loading: true, error: null }));
    matchingAPI.catalog(0, 200)
      .then((res) => { if (!cancelled) setState({ loading: false, error: null, products: res.products, total: res.total }); })
      .catch((err) => { if (!cancelled) setState({ loading: false, error: err.message, products: [], total: 0 }); });
    return () => { cancelled = true; };
  }, [version]);

  if (state.loading) return <div className="flex-center" style={{ paddingTop: 60 }}><Spinner size={32} /></div>;
  if (state.error) return <EmptyState icon="⚠" title="Could not load the catalog" subtitle={state.error} />;

  return (
    <>
      <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 12 }}>
        {state.total} products after merging duplicate listings across sellers
      </div>
      {state.products.map((product) => (
        <div key={product.familyId} style={{ padding: 14, marginBottom: 12, border: '1px solid var(--border2)', borderRadius: 'var(--r)', background: 'var(--surface)' }}>
          <div className="flex-between" style={{ alignItems: 'flex-start', gap: 8 }}>
            <div style={{ minWidth: 0 }}>
              <div style={{ fontWeight: 600, fontSize: 14, lineHeight: 1.35 }}>{product.title}</div>
              <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 2 }}>
                {product.familyId}, {product.listingCount} listing{product.listingCount === 1 ? '' : 's'}
              </div>
            </div>
            {product.variants.length > 1 && (
              <span className="badge badge-purple" style={{ flexShrink: 0 }}>{product.variants.length} variants</span>
            )}
          </div>
          {product.variants.map((variant) => (
            <div key={variant.unifiedId} style={{ marginTop: 10, paddingTop: 10, borderTop: '1px solid var(--border2)' }}>
              <div className="flex-between" style={{ fontSize: 12 }}>
                <span style={{ fontWeight: 600 }}>
                  {variant.color || 'Colour not stated'}{variant.pack > 1 ? `, pack of ${variant.pack}` : ''}
                </span>
                <span>from {rupees(variant.bestPrice)}</span>
              </div>
              <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 2 }}>
                {variant.unifiedId}: {variant.sellers.join(', ')}
              </div>
            </div>
          ))}
        </div>
      ))}
    </>
  );
}

function MetricTile({ label, value }) {
  return (
    <div style={{ flex: 1, padding: 12, borderRadius: 'var(--r-sm)', background: 'var(--teal-xxlight)', border: '1px solid var(--teal-light)' }}>
      <div style={{ fontSize: 20, fontWeight: 700, color: 'var(--teal-darker)' }}>{value}</div>
      <div style={{ fontSize: 11, color: 'var(--muted)' }}>{label}</div>
    </div>
  );
}

function QualityTab({ version }) {
  const [state, setState] = useState({ loading: true, error: null, summary: null, evaluation: null });

  useEffect(() => {
    let cancelled = false;
    setState((s) => ({ ...s, loading: true, error: null }));
    Promise.all([matchingAPI.summary(), matchingAPI.evaluation().catch(() => null)])
      .then(([s, e]) => { if (!cancelled) setState({ loading: false, error: null, summary: s.summary, evaluation: e?.evaluation ?? null }); })
      .catch((err) => { if (!cancelled) setState({ loading: false, error: err.message, summary: null, evaluation: null }); });
    return () => { cancelled = true; };
  }, [version]);

  if (state.loading) return <div className="flex-center" style={{ paddingTop: 60 }}><Spinner size={32} /></div>;
  if (state.error) return <EmptyState icon="⚠" title="Could not load metrics" subtitle={state.error} />;

  const { summary, evaluation } = state;
  const blocking = evaluation?.blocking;

  return (
    <>
      <div className="section-title" style={{ marginBottom: 10 }}>Matching</div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
        <MetricTile label="Listings" value={summary.listings.accepted} />
        <MetricTile label="Unified products" value={summary.clusters.variant.clusters} />
        <MetricTile label="Awaiting review" value={summary.reviewPending} />
      </div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        <MetricTile label="Auto-matched pairs" value={summary.decisions.match} />
        <MetricTile label="Variant links" value={summary.matchedRelations.variant} />
        <MetricTile label="Merges blocked" value={summary.vetoedMerges} />
      </div>

      {evaluation && (
        <>
          <div className="section-title" style={{ marginBottom: 10 }}>Accuracy against labelled data</div>
          <div style={{ overflowX: 'auto', marginBottom: 20 }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
              <thead>
                <tr style={{ textAlign: 'left', color: 'var(--muted)' }}>
                  <th style={{ padding: '6px 4px' }}>Level</th>
                  <th style={{ padding: '6px 4px' }}>Precision</th>
                  <th style={{ padding: '6px 4px' }}>Recall</th>
                  <th style={{ padding: '6px 4px' }}>F1</th>
                </tr>
              </thead>
              <tbody>
                {[['Same item', evaluation.variant], ['Same product', evaluation.family]].map(([label, m]) => (
                  <tr key={label} style={{ borderTop: '1px solid var(--border2)' }}>
                    <td style={{ padding: '6px 4px', fontWeight: 600 }}>{label}</td>
                    <td style={{ padding: '6px 4px' }}>{percent(m.precision)}</td>
                    <td style={{ padding: '6px 4px' }}>{percent(m.recall)}</td>
                    <td style={{ padding: '6px 4px' }}>{percent(m.f1)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="section-title" style={{ marginBottom: 10 }}>Candidate generation</div>
          <div style={{ fontSize: 13, lineHeight: 1.8, marginBottom: 20 }}>
            <div className="flex-between"><span style={{ color: 'var(--muted)' }}>All possible pairs</span><span>{blocking.allPairs.toLocaleString('en-IN')}</span></div>
            <div className="flex-between"><span style={{ color: 'var(--muted)' }}>Pairs actually compared</span><span>{blocking.candidatePairs.toLocaleString('en-IN')}</span></div>
            <div className="flex-between"><span style={{ color: 'var(--muted)' }}>Comparisons avoided</span><span>{percent(blocking.reductionRatio)}</span></div>
            <div className="flex-between"><span style={{ color: 'var(--muted)' }}>True pairs kept</span><span>{percent(blocking.pairCompleteness)}</span></div>
          </div>

          <div className="section-title" style={{ marginBottom: 10 }}>Threshold trade-off</div>
          <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 8 }}>
            Raising the auto-match threshold avoids wrong merges but misses more true matches.
          </div>
          {evaluation.sweep.map((row) => (
            <div key={row.threshold} style={{ display: 'grid', gridTemplateColumns: '40px 1fr 1fr', gap: 8, alignItems: 'center', marginBottom: 6, fontSize: 11 }}>
              <span style={{ fontWeight: 600 }}>{row.threshold.toFixed(2)}</span>
              <div><ScoreBar value={row.variant.precision} /><span style={{ color: 'var(--muted)' }}>Precision {percent(row.variant.precision)}</span></div>
              <div><ScoreBar value={row.variant.recall} color="var(--gold)" /><span style={{ color: 'var(--muted)' }}>Recall {percent(row.variant.recall)}</span></div>
            </div>
          ))}
        </>
      )}
    </>
  );
}

export default function MatchReview() {
  const nav = useNavigate();
  const [tab, setTab] = useState('review');
  const [version, setVersion] = useState(0);
  const bump = useCallback(() => setVersion((v) => v + 1), []);

  return (
    <div className="screen">
      <BackNav title="Product matching" right={
        <button type="button" className="btn btn-ghost btn-sm" onClick={() => nav('/')}>Shop</button>
      } />
      <div role="tablist" aria-label="Matching views" style={{ display: 'flex', gap: 8, padding: '8px 16px 12px', borderBottom: '1px solid var(--border2)' }}>
        {TABS.map((t) => (
          <button key={t.id} type="button" role="tab" aria-selected={tab === t.id}
            className={`chip${tab === t.id ? ' active' : ''}`}
            onClick={() => setTab(t.id)}
            style={tab === t.id ? { background: 'var(--teal-dark)', color: '#fff', borderColor: 'var(--teal-dark)' } : undefined}>
            {t.label}
          </button>
        ))}
      </div>
      <div className="screen-scroll" style={{ padding: '14px 16px 32px' }}>
        {tab === 'review' && <ReviewTab onChanged={bump} />}
        {tab === 'catalog' && <CatalogTab version={version} />}
        {tab === 'quality' && <QualityTab version={version} />}
      </div>
    </div>
  );
}
