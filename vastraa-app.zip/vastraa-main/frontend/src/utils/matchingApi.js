import axios from 'axios';

/**
 * Client for the product-matching API (/api/matching).
 *
 * Kept separate from utils/api.js on purpose: the shared client redirects to
 * /login on any 401 and falls back to offline data, neither of which is
 * right for the review tool, which must report exactly what the server said.
 */
const client = axios.create({
  baseURL: '/api/matching',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
});

client.interceptors.request.use((config) => {
  const token = localStorage.getItem('vastra_token');
  if (token && !token.startsWith('local-')) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

client.interceptors.response.use(
  (res) => res.data,
  (err) => {
    const status = err.response?.status ?? 0;
    const message = err.response?.data?.message
      || (status === 0 ? 'Matching service is unreachable. Start the backend and try again.' : 'Request failed');
    return Promise.reject({ status, message });
  },
);

export const matchingAPI = {
  summary: () => client.get('/summary'),
  evaluation: () => client.get('/evaluation'),
  reviewQueue: (limit = 20) => client.get('/review', { params: { limit } }),
  decide: (key, decision) => client.post('/review', { key, decision }),
  undo: (key) => client.post('/review/undo', { key }),
  catalog: (offset = 0, limit = 50) => client.get('/catalog', { params: { offset, limit } }),
};

export const matchingImageUrl = (relativePath) => (
  relativePath ? `/api/matching/images/${relativePath.split('/').map(encodeURIComponent).join('/')}` : null
);
